from __future__ import annotations

from collections.abc import Callable
from typing import Any

from .metadata import LiveInjectionViolation, ScopeLeak


class providifyError(Exception):
    """Base class for all errors in the providify framework."""

    pass


class BindingError(providifyError):
    """Base class for all binding-related errors."""

    pass


class ProviderBindingNotDecoratedError(BindingError):
    """Raised when a provider function is missing the required @Provider decorator."""

    def __init__(self, provider_fn: Callable[..., Any]):
        super().__init__(
            f"Provider function {provider_fn.__name__} is missing required @Provider decorator."
        )


class ClassBindingNotDecoratedError(BindingError):
    """Raised when a class provider is not decorated with @Component or @Singleton."""

    def __init__(self, cls: type):
        super().__init__(
            f"Class {cls.__name__} is not a DI component. Missing @Component or @Singleton decorator?"
        )


class NotDecoratedError(BindingError):
    """Raised when a class or function is not decorated with the required DI decorator."""

    def __init__(self, obj: Any):
        super().__init__(f"{obj} is not decorated with the required DI decorator.")


class ProviderAlreadyDecorated(providifyError):
    """Raised when a provider function is decorated more than once."""

    def __init__(self, fn: Callable[..., Any]):
        super().__init__(f"'{fn.__name__}' is already decorated with @Provider.")


class ClassAlreadyDecorated(providifyError):
    """Raised when a class is decorated with more than one scope decorator."""

    def __init__(self, cls: type):
        super().__init__(
            f"'{cls.__name__}' is already decorated with a scope decorator(@Component,@Singleton...)."
        )


class CircularDependencyError(providifyError):
    """
    Raised when a circular dependency is detected during resolution.

    Example:
        A → B → C → A

    This means A depends on B, B depends on C, and C depends back on A —
    the container cannot resolve this without infinite recursion.
    """

    def __init__(self, cycle: str) -> None:
        self.cycle = cycle
        super().__init__(
            f"Circular dependency detected: {cycle}\n"
            f"Break the cycle by:\n"
            f"  1. Introducing an interface between the dependent classes\n"
            f"  2. Using lazy injection — Lazy[T]\n"
            f"  3. Restructuring to remove the mutual dependency"
        )


class ValidationError(providifyError):
    pass


class LiveInjectionRequiredError(ValidationError):
    """Raised when a REQUEST or SESSION scoped dep is not wrapped in Live[T].

    A longer-lived component (SINGLETON or SESSION) that injects a scoped dep
    via ``Inject[T]``, ``Lazy[T]``, or a plain type annotation will capture a
    single instance at construction time. That instance becomes stale the moment
    the scope rotates to a new request or session — wrong and often a security
    issue (e.g. one user's JWT leaking into another user's request).

    ``Live[T]`` is the correct fix: it wraps the dep in a proxy that re-resolves
    from the container on every access, always returning the instance that belongs
    to the *currently active* scope context.

    Attributes:
        violations: Structured list of all violating parameters — one entry per
            constructor parameter that should be changed to Live[T].
    """

    def __init__(self, violations: list[LiveInjectionViolation]) -> None:
        self.violations = violations
        lines = [
            f"  - '{v.param_name}' in {v.binding[0].__name__} "
            f"(scope={v.binding[1].name}) injects {v.dep[0].__name__} "
            f"(scope={v.dep[1].name}) without Live[T].\n"
            f"    Fix: change `{v.param_name}: Inject[{v.dep[0].__name__}]` "
            f"→ `{v.param_name}: Live[{v.dep[0].__name__}]`\n"
            f"    Reason: Inject[T] and Lazy[T] capture one instance at "
            f"construction time — that instance becomes stale across "
            f"{v.dep[1].name.lower()} boundaries."
            for v in violations
        ]
        super().__init__(
            "Live[T] required for REQUEST/SESSION scoped dependencies:\n"
            + "\n".join(lines)
        )


class ScopeViolationDetectedError(ValidationError):
    def __init__(self, scope_violations: list[ScopeLeak]):
        self.scope_violations = scope_violations
        message = "\n".join(
            [
                f"Scope leak detected from binding {violation.binding[0].__name__} with scope {violation.binding[1].name} to reference {violation.reference[0].__name__} with scope {violation.reference[1].name}"
                for violation in self.scope_violations
            ]
        )
        super().__init__(message)


class AnnotationResolutionError(ValidationError):
    """Raised when a validator cannot even READ a binding's annotations.

    A validator's whole job is to prove a binding is safe (no scope leaks).
    If ``get_type_hints()`` itself fails — e.g. a ``NameError`` from a
    locally-defined type absent from both ``__globals__`` and the container's
    ``localns`` — the validator has no evidence either way. Silently treating
    "I don't know" as "no leaks found" (returning an empty list) reports a
    clean bill of health the validator cannot actually prove, which is worse
    than raising: it is a false negative that looks identical to genuine
    safety. Raising instead forces the container to refuse to start rather
    than lie about having validated something it never could evaluate.

    Subclassing ``ValidationError`` (rather than, say, ``LookupError``)
    matters operationally: ``validate_all()`` catches ``ValidationError``-
    family exceptions and appends ``str(e)`` to its violations list, so an
    unresolvable annotation surfaces as a *violation message* — never as a
    crash that bypasses the normal "collect every violation" flow, and never
    as a false "you're fine".

    Phase 7 (per-parameter resolution) narrows the failure to a single
    parameter or class attribute rather than an entire signature — ``param_name``
    carries that extra precision when known, so the message can say exactly
    *which* injection point could not be resolved instead of naming only the
    owning class/function.

    Attributes:
        owner_name: Human-readable name of the binding/class/function whose
            annotations could not be resolved (e.g. ``"Impl.__init__"`` or
            ``"@Provider(make_impl)"``).
        cause: The original exception raised by ``get_type_hints()`` (e.g.
            ``NameError``, ``AttributeError``) — chained via ``__cause__``.
        param_name: The specific parameter or class attribute that could not
            be resolved, when resolution is per-parameter (``None`` when the
            failure is whole-signature, e.g. release A's validators).
    """

    def __init__(
        self,
        owner_name: str,
        cause: Exception,
        param_name: str | None = None,
    ) -> None:
        self.owner_name = owner_name
        self.cause = cause
        self.param_name = param_name
        # WHY a conditional clause instead of always interpolating param_name:
        # release A call sites (whole-signature validators) never pass it, and
        # "for parameter 'None'" in every message would be actively misleading.
        located_at = f" parameter '{param_name}'" if param_name is not None else ""
        super().__init__(
            f"Cannot resolve type hints for '{owner_name}'{located_at} "
            f"({type(cause).__name__}: {cause}). Scope-leak validation cannot "
            f"run for it, so the container refuses to start rather than "
            f"report a clean bill of health it cannot prove.\n"
            f"Fix: import the annotated type at runtime instead of under "
            f"TYPE_CHECKING, or move locally-defined types to module level."
        )
