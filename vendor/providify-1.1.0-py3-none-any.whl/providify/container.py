from __future__ import annotations

import asyncio
import collections
import functools
import inspect
import logging
import threading
import types
import warnings
import weakref
from collections.abc import Callable
from types import ModuleType
from typing import (
    Annotated,
    Any,
    ClassVar,
    TypeVar,
    Union,
    get_args,
    get_origin,
)

from ._annotations import (
    _annotation_namespaces,
    _eval_annotation,
    resolve_class_annotations,
    resolve_params,
)
from .binding import AnyBinding, ClassBinding, ProviderBinding
from .decorator.interceptor import (
    _get_around_invoke_method,
    _is_interceptor,
    _is_interceptor_binding,
)
from .decorator.lifecycle import (
    LifecycleMarker,
    _get_disposes_marker,
    _get_observes_marker,
)
from .descriptor import DIContainerDescriptor
from .exceptions import (
    AnnotationResolutionError,
    CircularDependencyError,
    LiveInjectionRequiredError,
)
from .metadata import (
    LiveInjectionViolation,
    Scope,
    ScopeLeak,
    _get_metadata,
    _get_provider_metadata,
    _has_configuration_module,
    _has_own_metadata,
    _is_scope_leak,
)
from .resolution import (
    _UNRESOLVED,
    _current_injection_point,
    _current_stack,
    _format_cycle,
    _resolution_stack,
    _singleton_in_progress,
)
from .scanner import ContainerScanner, DefaultContainerScanner
from .scope import ScopeContext
from .type import (
    DelegateMeta,
    EventMeta,
    EventProxy,
    InjectionPoint,
    InjectMeta,
    InstanceMeta,
    InstanceProxy,
    InvocationContext,
    LazyMeta,
    LazyProxy,
    LiveMeta,
    LiveProxy,
    NamedMeta,
    _has_providify_metadata,
    _providify,
    _unwrap_classvar,
)
from .utils import _interface_matches, _type_name

T = TypeVar("T")

logger = logging.getLogger(__name__)


def _unwrap_union(hint: Any) -> tuple[list[Any], bool] | None:
    """Decompose a Union type hint into its candidate types and optionality.

    Handles both union representations Python provides:
    - ``typing.Union[T1, T2]`` and ``Optional[T]`` (== ``Union[T, None]``) —
      detected via ``get_origin(hint) is Union``.
    - Python 3.10+ pipe syntax ``T1 | T2`` — produces ``types.UnionType``,
      detected via ``isinstance(hint, types.UnionType)``.

    Returns ``None`` for any hint that is not a union, so callers can use a
    simple ``if _unwrap_union(hint) is not None:`` guard without worrying about
    false positives from plain concrete types or generics.

    Args:
        hint: Any type annotation, already evaluated (not a string).

    Returns:
        A ``(candidates, is_optional)`` tuple where:
        - ``candidates`` — non-``NoneType`` args, preserving declaration order.
        - ``is_optional`` — ``True`` iff ``NoneType`` appeared in the union args
          (i.e. the whole union is nullable / optional).
        Or ``None`` if *hint* is not a union type at all.

    Edge cases:
        - ``Union[None]``          → candidates=[], is_optional=True (degenerate)
        - ``Union[T]``             → not produced by Python; ``Union[T]`` collapses
          to bare ``T`` at parse time, so this helper never sees it.
        - Nested unions (Python flattens them) → already handled by ``get_args``.

    Example:
        >>> _unwrap_union(Optional[int])
        ([<class 'int'>], True)
        >>> _unwrap_union(int | str | None)
        ([<class 'int'>, <class 'str'>], True)
        >>> _unwrap_union(int)
        None
    """
    # DESIGN: Two separate isinstance/get_origin checks are needed because
    # Python uses different runtime representations for the two union syntaxes:
    #   - typing.Union produces a _GenericAlias whose get_origin() returns Union
    #   - X | Y produces a types.UnionType which has no get_origin() result
    # Unifying them here avoids duplicating this detection in every call site.
    if isinstance(hint, types.UnionType):
        # Python 3.10+ pipe syntax: int | str | None
        args = get_args(hint)
    elif get_origin(hint) is Union:
        # typing.Union[...] and Optional[T] (which is Union[T, None])
        args = get_args(hint)
    else:
        return None

    none_type = type(None)
    is_optional = none_type in args
    # Preserve declaration order — important for Union[T1, T2] where T1 is tried first
    candidates = [a for a in args if a is not none_type]
    return candidates, is_optional


# ─────────────────────────────────────────────────────────────────
#  _ScopedContainer — installs a temporary container as global
# ─────────────────────────────────────────────────────────────────


class _ScopedContainer:
    """
    Installs a fresh DIContainer as the global for the duration of the block.
    Restores the previous global on exit — even if an exception is raised.

    Supports both sync and async usage:
        with DIContainer.scoped() as c: ...
        async with DIContainer.scoped() as c: ...
    """

    def __init__(self) -> None:
        self._previous: DIContainer | None = None
        self._container: DIContainer | None = None

    def _install(self) -> DIContainer:
        """Creates and installs a fresh container as the global."""
        self._previous = DIContainer._global
        self._container = DIContainer()
        DIContainer._global = self._container
        return self._container

    def _restore(self) -> None:
        """Restores the previous global — always called in finally."""
        DIContainer._global = self._previous

    # ── Sync context manager ──────────────────────────────────────

    def __enter__(self) -> DIContainer:
        return self._install()

    def __exit__(self, *_: object) -> None:
        self._restore()

    # ── Async context manager ─────────────────────────────────────

    async def __aenter__(self) -> DIContainer:
        # No I/O here — install is CPU only, no need to await
        return self._install()

    async def __aexit__(self, *_: object) -> None:
        self._restore()


# ─────────────────────────────────────────────────────────────────
#  _InterceptorProxy — transparent AOP wrapper for @Interceptor
# ─────────────────────────────────────────────────────────────────


class _InterceptorProxy:
    """Wraps a bean instance and intercepts method calls via the interceptor chain.

    All attribute accesses are delegated to the underlying ``_target``. For
    callable attributes the proxy wraps the call in an ``InvocationContext``
    so each ``@AroundInvoke`` method in *chain* is invoked before the real
    method body runs.

    Note:
        ``isinstance(proxy, TargetClass)`` returns ``False``. Use
        ``type(proxy._target)`` when class identity is required.
    """

    __slots__ = ("_target", "_chain")

    def __init__(self, target: object, chain: list[tuple[object, str]]) -> None:
        object.__setattr__(self, "_target", target)
        object.__setattr__(self, "_chain", chain)

    def __getattr__(self, name: str) -> Any:
        attr = getattr(object.__getattribute__(self, "_target"), name)
        chain = object.__getattribute__(self, "_chain")
        if not callable(attr):
            return attr

        def _intercepted(*args: Any, **kwargs: Any) -> Any:
            ctx = InvocationContext(
                target=object.__getattribute__(self, "_target"),
                method=attr,
                parameters=args,
                kwargs=kwargs,
                _chain=list(chain),
            )
            return ctx.proceed()

        return _intercepted

    def __repr__(self) -> str:
        target = object.__getattribute__(self, "_target")
        return f"_InterceptorProxy({target!r})"


# ─────────────────────────────────────────────────────────────────
#  DIContainer — central dependency injection container
# ─────────────────────────────────────────────────────────────────


class DIContainer:
    """Central dependency injection container — supports sync and async resolution.

    Maintains a registry of :class:`~providify.binding.AnyBinding` objects and
    resolves them on demand, respecting scope caching (singleton, request, session).
    Operates in two phases:

    1. **Registration** — ``bind()``, ``register()``, ``provide()``, ``scan()``
       add bindings.  No validation occurs during this phase so the registry
       can be built in any order.
    2. **Resolution** — the first call to ``get()`` / ``aget()`` / ``get_all()`` /
       ``aget_all()`` triggers ``validate_bindings()`` (once), then resolves.

    Thread safety:  ✅ Safe — the global instance is created under
                    ``threading.Lock`` (double-checked locking).  Individual
                    resolution calls are not locked; concurrent reads of
                    ``_bindings`` and ``_singleton_cache`` rely on the GIL for
                    dict/list safety.  ⚠️ If you mutate bindings from multiple
                    threads after the first resolution, add external locking.
    Async safety:   ✅ Safe — the global instance is created under
                    ``asyncio.Lock`` (created lazily; requires a running loop).
                    ``_resolution_stack`` is a ``ContextVar`` — each asyncio
                    task gets its own isolated stack, preventing cross-task
                    cycle-detection false positives.

    Edge cases:
        - Adding a binding after ``get()`` resets ``_validated`` so the next
          resolution re-runs ``validate_bindings()`` over the full registry.
        - Resolving a ``REQUEST``/``SESSION``-scoped binding outside an active
          scope context raises ``RuntimeError`` immediately.
        - Singleton resolution is protected by per-key double-check locking
          (Feature 4) — exactly one instance is created even under concurrent
          access from multiple threads or tasks.

    Inheritance and MRO:
        The two injection paths differ deliberately in how they handle MRO:

        * **``__init__`` parameters** — the container reads *only* the
          declared signature of the class being constructed.  If a subclass
          overrides ``__init__``, only the subclass's parameters are injected.
          When ``__init__`` is *not* overridden, Python's own MRO already
          resolves ``cls.__init__`` to the parent's method, so parent params
          are injected automatically with no special handling.  Walking parent
          ``__init__`` signatures on top of that would conflict with any
          ``super().__init__(arg)`` call the developer writes — the same dep
          could be resolved twice, producing two separate instances.

        * **Class-level annotations** — :meth:`_resolve_class_annotations`
          (Phase 7's per-attribute replacement for a single
          ``get_type_hints(cls)`` call) walks the full MRO, so
          ``var: Inject[T]`` annotations declared on a parent class are
          inherited and injected on every subclass instance automatically.  This
          is the right extension point for shared deps that all subclasses need.
    """

    _global: ClassVar[DIContainer | None] = None
    # Two locks — one per execution context.
    # threading.Lock for sync callers, asyncio.Lock for async callers.
    _sync_lock: ClassVar[threading.Lock] = threading.Lock()
    _async_lock: ClassVar[asyncio.Lock | None] = (
        None  # created lazily — needs event loop
    )

    # Exposed as a class attribute so callers (and tests) that already have
    # a resolved `Annotated[...]` hint in hand can classify its union shape
    # without needing a container instance — e.g. asserting that
    # `Live[Foo | None]`'s underlying union carries `optional=True`.
    # `optional` is a property of the *evaluated hint object*, never stamped
    # onto the marker itself (`LiveMeta`/`InjectMeta` have no `optional`
    # field to stamp for this case) — this module-level helper is the single
    # source of truth for that derivation; the container's instance methods
    # (`_resolve_hint_sync`/`_async`) call the free function directly.
    _unwrap_union = staticmethod(_unwrap_union)

    # ── Initialisation ────────────────────────────────────────────

    def __init__(
        self,
        *,
        scan: str | list[str] | None = None,
        recursive: bool = True,
    ) -> None:
        """Initialise an empty container with no bindings.

        All state is instance-local — multiple containers can coexist in the
        same process without interfering (e.g. one per test via ``scoped()``).

        Args:
            scan:      A fully-qualified module name (``str``), a list of module
                       names, or ``None`` (default).  When provided, each module
                       is scanned immediately at construction time — equivalent
                       to calling ``container.scan(name, recursive=recursive)``
                       for each name after the container is created.
                       Useful for applications that want a single, declarative
                       registration step:

                       .. code-block:: python

                           container = DIContainer(scan="myapp", recursive=True)
                           # all @Component/@Singleton/@Provider in myapp are
                           # registered before the first get() call.

            recursive: When ``True`` (default), sub-packages under each *scan*
                       entry are walked recursively.  Has no effect when *scan*
                       is ``None``.

        Returns:
            None

        Raises:
            ModuleNotFoundError: If a module name in *scan* cannot be imported.

        Edge cases:
            - ``scan=None`` (default) — no scanning, backward-compatible.
            - ``scan=[]`` — empty list is treated the same as ``None``.
            - ``scan="myapp"`` — single string, scanned once with *recursive*.
            - ``scan=["a", "b"]`` — each module scanned left-to-right; later
              modules may add bindings that complement earlier ones.
        """
        self._bindings: list[AnyBinding] = []
        self._singleton_cache: dict[Any, object] = {}
        # DESIGN: ScopeContext receives @PreDestroy callbacks so it can run
        # lifecycle hooks exactly when a request/session scope frame exits —
        # before the cache is popped.  Both sync and async callbacks are wired
        # here; ScopeContext calls whichever is appropriate for its context manager.
        #
        # Tradeoffs:
        #   ✅ Lifecycle hooks fire at the right moment (scope exit, not shutdown)
        #   ✅ Container logic stays in the container; ScopeContext stays generic
        #   ❌ Two extra bound-method references stored on every ScopeContext
        # DESIGN: all four callbacks use the same underlying methods —
        # invalidate_session / ainvalidate_session are semantically identical
        # to scope exit (run @PreDestroy, discard cache).  Separate callbacks
        # keep ScopeContext's control flow explicit rather than special-casing
        # the invalidation path inside the shared on_scope_exit callback.
        self.scope_context: ScopeContext = ScopeContext(
            on_scope_exit=self._run_pre_destroy_for_scope,
            on_scope_exit_async=self._arun_pre_destroy_for_scope,
            on_invalidate_session=self._run_pre_destroy_for_scope,
            on_invalidate_session_async=self._arun_pre_destroy_for_scope,
        )
        self._scanner: ContainerScanner = DefaultContainerScanner(self)
        # Starts unvalidated — first resolution triggers validate_bindings()
        self._validated: bool = False
        # Lazily-built cache for _collect_kwargs — maps class __name__ → class.
        # Set to None whenever a binding is added so it is rebuilt on next use.
        # In the common case (all bindings registered before the first get()),
        # the dict is built exactly once and reused for every resolution.
        self._localns_cache: dict[str, type] | None = None
        # Phase 7 (Plan 001) — per-callable/per-class resolved-hints cache.
        # Key: the callable/class object itself (fn, cls, or cls.__init__) —
        # see `_invalidate_type_caches` and `_resolve_params` /
        # `_resolve_class_annotations` for the full caching rationale
        # (plan §7.4). Dies together with `_localns_cache` because a
        # resolved hint's correctness depends on `_build_localns()`.
        self._hints_cache: dict[Any, dict[str, Any]] = {}

        # ── Feature 4: per-key singleton locks (double-check locking) ──────
        # DESIGN: _singleton_locks maps a cache key to a per-key threading.Lock.
        # _singleton_lock_guard protects the creation of per-key locks so that
        # two threads that simultaneously reach a cold cache entry do not both
        # create new lock objects — only the first one's lock is used.
        #
        # Tradeoffs:
        #   ✅ True double-check locking: one instance created per singleton key
        #   ✅ Only SINGLETON scope is affected — REQUEST/SESSION use ContextVar
        #      isolation which already prevents races at the scope level
        #   ❌ Small overhead for the guard lock on first access per key
        #   ❌ Lock dict grows with the number of distinct singleton keys (bounded)
        self._singleton_locks: dict[Any, threading.Lock] = {}
        self._singleton_lock_guard: threading.Lock = threading.Lock()

        # ── Feature 4: per-key asyncio locks ────────────────────────────────
        # Created lazily inside _instantiate_async — asyncio.Lock() requires a
        # running event loop at creation time, so we cannot create them here.
        # _async_singleton_locks is the dict; the guard is the same
        # _singleton_lock_guard (creating asyncio.Lock also needs protection).
        # DESIGN: asyncio.Lock instances must NEVER be created at module level
        # or in __init__ — they require an active event loop.
        self._async_singleton_locks: dict[Any, asyncio.Lock] = {}

        # ── Jakarta CDI parity state ───────────────────────────────
        # @Alternative — activated per-container; excluded by default from _filter()
        self._enabled_alternatives: set[type] = set()
        # @Interceptor — registered interceptor classes applied to all resolved instances
        self._interceptor_classes: list[type] = []
        # Event[T] / @Observes — maps event type → [(weakref, method_name)]
        self._observers: dict[type, list] = {}
        # @Component(track=True) — tracked DEPENDENT instances for flush_dependents()
        self._tracked_dependents: list[object] = []

        # ── Auto-scan at construction time ────────────────────────
        # DESIGN: Eager scan (at __init__) rather than lazy scan (deferred to
        # first get()) was chosen because it makes errors surface at the point
        # of misconfiguration (container creation) rather than later at first
        # resolution, which is harder to trace.
        #
        # Tradeoffs:
        #   ✅ Fail-fast — ModuleNotFoundError pinpoints the bad module name
        #   ✅ All bindings present before any manual bind() / register() call
        #   ❌ If scan modules have side-effects on import, they run at __init__
        #      rather than deferred (acceptable; import side-effects are rare)
        #
        # Alternative considered: lazy scan triggered by first get() — rejected
        # because it would surface import errors far from the registration site.
        if scan is not None:
            # Normalise to a list so the loop below is uniform
            modules = [scan] if isinstance(scan, str) else list(scan)
            for module_name in modules:
                self.scan(module_name, recursive=recursive)

    # ── Global accessor ───────────────────────────────────────────

    @classmethod
    def current(cls) -> DIContainer:
        """Return the global container (sync version).

        Uses ``threading.Lock`` — safe to call from sync code.

        Returns:
            The global singleton ``DIContainer``, creating it if needed.
        """
        if cls._global is None:
            with cls._sync_lock:
                if cls._global is None:
                    cls._global = cls()
        return cls._global

    @classmethod
    async def acurrent(cls) -> DIContainer:
        """Return the global container (async version).

        Uses ``asyncio.Lock`` — never blocks the event loop.

        Returns:
            The global singleton ``DIContainer``, creating it if needed.

        Example:
            container = await DIContainer.acurrent()
        """
        if cls._global is None:
            # Create asyncio.Lock lazily — requires a running event loop
            if cls._async_lock is None:
                cls._async_lock = asyncio.Lock()

            async with cls._async_lock:
                # Double-checked locking — same pattern as the sync version
                if cls._global is None:
                    cls._global = cls()

        return cls._global

    @classmethod
    def reset(cls) -> None:
        """Reset the global container — use in test teardown.

        Returns:
            None
        """
        with cls._sync_lock:
            cls._global = None
            cls._async_lock = None  # reset lock too — next acurrent() recreates it

    @classmethod
    def scoped(cls) -> _ScopedContainer:
        """Return a context manager that installs a fresh container as global.

        Supports both sync and async:

            with DIContainer.scoped() as container: ...
            async with DIContainer.scoped() as container: ...

        Returns:
            A :class:`_ScopedContainer` context manager.
        """
        return _ScopedContainer()

    # ── Instance context manager ──────────────────────────────────
    #
    # DESIGN: DIContainer as a context manager manages the *instance* lifecycle
    # (bind → use → shutdown), whereas scoped() manages the *global* lifecycle
    # (temporarily swap the global container). They compose:
    #
    #     with DIContainer.scoped() as c:   # global swapped
    #         with c:                        # shutdown on exit ← this feature
    #             c.bind(...)
    #             c.get(...)
    #
    # Tradeoffs:
    #   ✅ Guarantees @PreDestroy hooks run even if an exception is raised.
    #   ✅ Caches are cleared automatically — no leaks between test cases.
    #   ❌ shutdown() raises if any @PreDestroy is async — callers must use
    #      async with container: ... (which calls ashutdown()) in that case.

    def __enter__(self) -> DIContainer:
        """Enter the container context — returns self for use in with-statements.

        Returns:
            self
        """
        return self

    def __exit__(self, *_: object) -> None:
        """Exit the container context and run synchronous shutdown.

        Calls shutdown(), which invokes every @PreDestroy hook on cached
        singletons and clears all instance caches.

        Args:
            _: Exception info — ignored; shutdown always runs regardless of
               whether the with-block raised.

        Returns:
            None  (does not suppress exceptions from the with-block)

        Raises:
            RuntimeError: If any @PreDestroy hook is async def — use
                ``async with container:`` (which calls ashutdown()) instead.
        """
        self.flush_dependents()
        self.shutdown()

    async def __aenter__(self) -> DIContainer:
        """Enter the container async context — returns self.

        Returns:
            self
        """
        return self

    async def __aexit__(self, *_: object) -> None:
        """Exit the container async context and run asynchronous shutdown.

        Calls ashutdown(), which awaits async @PreDestroy hooks and calls
        sync ones normally. Clears all instance caches afterward.

        Args:
            _: Exception info — ignored; shutdown always runs.

        Returns:
            None  (does not suppress exceptions from the async-with block)
        """
        await self.aflush_dependents()
        await self.ashutdown()

    # ── Registration ──────────────────────────────────────────────

    def bind(self, interface: Any, implementation: type) -> None:
        """Bind an interface type to a concrete implementation class.

        *interface* may be a concrete type (``Repository``) or a parameterised
        generic alias (``Repository[User]``).  The container will match any
        ``get(Repository[User])`` call — or a plain ``repo: Repository[User]``
        annotation — to this binding.

        Args:
            interface:      The abstract type (or base class) callers will resolve.
                            Accepts both concrete types and generic aliases.
            implementation: The concrete class that will be instantiated.
                            Must be a subclass of *interface*'s origin type and
                            must implement the exact type parameterisation.

        Returns:
            None
        """
        self._validated = False
        self._invalidate_type_caches()  # new binding — localns/hints must be rebuilt
        self._bindings.append(ClassBinding(interface, implementation))

        # When the caller binds an interface to a *different* implementation,
        # also self-bind the implementation so it is resolvable directly via
        # container.get(ConcreteClass) — not just via the interface key.
        # Without this, any injection point that declares the concrete type
        # (rather than the interface) gets a LookupError.
        # Guard: skip when interface IS implementation to avoid a duplicate
        # self-binding that would create ambiguous resolution.
        # exact_only=True ensures this synthetic entry is invisible to
        # supertype sweeps like get_all(BaseClass) — it only answers to
        # container.get(ConcreteClass) directly.
        if interface is not implementation:
            self._bindings.append(
                ClassBinding(implementation, implementation, exact_only=True)
            )

    def register(self, cls: type[T]) -> None:
        """Register a concrete class so it resolves to itself.

        The class must carry DI metadata (i.e. be decorated with
        ``@Component`` or ``@Singleton``).

        Args:
            cls: The decorated concrete class to register.

        Returns:
            None

        Raises:
            TypeError: If *cls* has no DI metadata, meaning it was not
                decorated with ``@Component`` or ``@Singleton``.
        """
        if not _has_own_metadata(cls):
            raise TypeError(
                f"{cls.__name__} must be decorated with @Component or @Singleton."
            )
        self._validated = False
        self._invalidate_type_caches()  # new binding — localns/hints must be rebuilt
        self._bindings.append(ClassBinding(cls, cls))

    def provide(self, fn: Callable[..., Any]) -> None:
        """Register a provider function (sync or async) as a binding.

        The function's return type annotation is used as the resolved interface.

        Args:
            fn: A callable that creates and returns the dependency.
                May be a regular function or an ``async def``.

        Returns:
            None
        """
        self._validated = False
        self._invalidate_type_caches()  # new binding — localns/hints must be rebuilt
        self._bindings.append(ProviderBinding(fn))

    # ── Warm-up ───────────────────────────────────────────────────

    def _validate_no_async_providers(self, bindings: list[AnyBinding]) -> None:
        """Pre-flight check — raise if any binding is an async provider.

        Separating validation from instantiation means warm_up either populates
        the singleton cache completely or not at all — it never leaves the cache
        in a partially-warmed state.

        Args:
            bindings: The list of bindings to validate. Typically the output of
                      _filter_singleton().

        Raises:
            RuntimeError: If any binding is an async ProviderBinding. Only the
                          first one is reported — fix one, re-run, discover the next.

        Edge cases:
            - Empty list → no-op, no error raised.

        Thread safety:  ✅ Read-only scan — no shared state is mutated.
        Async safety:   ✅ No awaits — safe to call from sync or async context.
        """
        for binding in bindings:
            if isinstance(binding, ProviderBinding) and binding.is_async:
                raise RuntimeError(
                    f"'{binding.fn.__name__}' is an async provider — "
                    f"use `await container.awarm_up()` instead."
                )

    def warm_up(
        self,
        qualifier: str | type | None = None,
        priority: int | None = None,
    ) -> None:
        """Eagerly instantiate all singleton bindings in the container (sync version).

        Validates the full binding list before instantiating anything — if any
        async provider is present the method raises immediately without touching
        the singleton cache, giving a clean all-or-nothing guarantee.

        Args:
            qualifier: Named qualifier to restrict which singletons are warmed up.
                       None means all qualifiers are included.
            priority:  Exact priority to match when filtering. None means all
                       priorities are included.

        Raises:
            RuntimeError: If any matching singleton is backed by an async provider.
                          The cache is NOT modified before the error is raised.
                          Call ``await container.awarm_up()`` instead.

        Edge cases:
            - No bindings match                  → no-op, no error raised.
            - qualifier + priority both None      → all singletons are warmed up.
            - Async provider anywhere in results  → raises before any instantiation ✅.
            - Binding already cached              → _instantiate_sync returns cached
                                                    instance — no double-construction.

        Thread safety:  ⚠️ Conditional — safe if called before the app goes
                            multi-threaded.
        Async safety:   ❌ Do NOT call from a running event loop — use awarm_up().

        Example:
            container.warm_up(qualifier="db", priority=10)
        """
        singleton_bindings = self._filter_singleton(
            qualifier=qualifier, priority=priority
        )
        # All-or-nothing guard — raises if any async provider is present
        self._validate_no_async_providers(singleton_bindings)
        for binding in singleton_bindings:
            self._instantiate_sync(binding)

    async def awarm_up(
        self,
        qualifier: str | type | None = None,
        priority: int | None = None,
    ) -> None:
        """Eagerly instantiate all singleton bindings in the container (async version).

        Mirrors ``warm_up`` but drives async providers with ``await``. Sync providers
        are still resolved synchronously — no unnecessary coroutine overhead is
        introduced for bindings that don't need it.

        Args:
            qualifier: Named qualifier to restrict which singletons are warmed up.
                       None means all qualifiers are included.
            priority:  Exact priority to match when filtering. None means all
                       priorities are included.

        Raises:
            Any exception raised by an async or sync provider during instantiation
            is propagated directly — warm-up does not swallow provider errors.

        Edge cases:
            - No bindings match              → no-op, no error raised.
            - Mix of sync and async providers → handled transparently ✅.
            - Binding already cached         → returns cached — no double-construction.
            - Async provider raises          → exception propagates; singletons
                                               resolved before the failure ARE cached ⚠️.

        Thread safety:  ⚠️ Conditional — assumes a single event loop drives warm-up.
        Async safety:   ✅ Must be called from within a running event loop.

        Example:
            await container.awarm_up(qualifier="db")
        """
        singleton_bindings = self._filter_singleton(
            qualifier=qualifier, priority=priority
        )
        for binding in singleton_bindings:
            if isinstance(binding, ProviderBinding) and binding.is_async:
                await self._instantiate_async(binding=binding)
            else:
                self._instantiate_sync(binding)

    # ── Sync resolution ───────────────────────────────────────────

    def get(
        self,
        cls: type[T] | Any,
        qualifier: str | type | None = None,
        priority: int | None = None,
    ) -> T:
        """Resolve a single instance synchronously.

        Selects the highest-priority binding that matches *cls* (and the
        optional *qualifier* / *priority* filters), then instantiates it.

        Args:
            cls:       The type to resolve.
            qualifier: Optional named qualifier to narrow the candidate set.
            priority:  Optional exact priority value to narrow the candidate set.

        Returns:
            A fully-injected instance of *cls*.

        Raises:
            LookupError:   If no binding is found for *cls*.
            RuntimeError:  If the best matching binding is an async provider —
                           use :meth:`aget` instead.
        """
        best = self._get_best_candidate(cls, qualifier=qualifier, priority=priority)
        # Guard — async providers cannot be resolved synchronously
        if isinstance(best, ProviderBinding) and best.is_async:
            raise RuntimeError(
                f"'{best.fn.__name__}' is an async provider — use await container.aget() instead."
            )
        if not self._validated:
            self.validate_bindings()
            self._validated = True
        return self._instantiate_sync(best)  # type: ignore[return-value]

    def get_all(
        self,
        cls: type[T] | Any,
        qualifier: str | type | None = None,
    ) -> list[T]:
        """Resolve every binding that matches *cls*, synchronously.

        Results are returned sorted by ascending priority (lowest number first).

        Args:
            cls:       The type to resolve.
            qualifier: Optional named qualifier to narrow the candidate set.

        Returns:
            A list of fully-injected instances, ordered by binding priority.

        Raises:
            LookupError:  If no binding is found for *cls*.
            RuntimeError: If any matching binding is an async provider —
                          use :meth:`aget_all` instead.
        """
        candidates = self._filter(cls, qualifier=qualifier)
        if not candidates:
            raise LookupError(f"No bindings found for '{_type_name(cls)}'.")

        # Guard — fail early if any candidate is async
        async_providers = [
            b for b in candidates if isinstance(b, ProviderBinding) and b.is_async
        ]
        if async_providers:
            names = ", ".join(b.fn.__name__ for b in async_providers)
            raise RuntimeError(
                f"Async providers [{names}] cannot be resolved with get_all(). "
                f"Use await container.aget_all() instead."
            )
        if not self._validated:
            self.validate_bindings()
            self._validated = True
        return [
            self._instantiate_sync(b)  # type: ignore[misc]
            for b in sorted(candidates, key=lambda b: b.priority)
        ]

    # ── Async resolution ──────────────────────────────────────────

    async def aget(
        self,
        cls: type[T] | Any,
        qualifier: str | type | None = None,
        priority: int | None = None,
    ) -> T:
        """Resolve a single instance asynchronously.

        Works transparently with both sync and async providers — async providers
        are awaited automatically.

        Args:
            cls:       The type to resolve.
            qualifier: Optional named qualifier to narrow the candidate set.
            priority:  Optional exact priority value to narrow the candidate set.

        Returns:
            A fully-injected instance of *cls*.

        Raises:
            LookupError: If no binding is found for *cls*.

        Example:
            svc = await container.aget(NotificationService)
        """
        best = self._get_best_candidate(cls, qualifier=qualifier, priority=priority)
        if not self._validated:
            self.validate_bindings()
            self._validated = True
        return await self._instantiate_async(best)  # type: ignore[return-value]

    async def aget_all(
        self,
        cls: type[T] | Any,
        qualifier: str | type | None = None,
    ) -> list[T]:
        """Resolve every binding that matches *cls*, asynchronously.

        Handles both sync and async providers — each binding is awaited only
        if its provider is a coroutine function.

        Args:
            cls:       The type to resolve.
            qualifier: Optional named qualifier to narrow the candidate set.

        Returns:
            A list of fully-injected instances, ordered by binding priority.

        Raises:
            LookupError: If no binding is found for *cls*.

        Example:
            services = await container.aget_all(NotificationService)
        """
        candidates = self._filter(cls, qualifier=qualifier)
        if not candidates:
            raise LookupError(f"No bindings found for '{_type_name(cls)}'.")
        if not self._validated:
            self.validate_bindings()
            self._validated = True
        return [
            await self._instantiate_async(b)  # type: ignore[misc]
            for b in sorted(candidates, key=lambda b: b.priority)
        ]

    # ── Filtering helpers ─────────────────────────────────────────

    def _filter(
        self,
        cls: type,
        qualifier: str | type | None = None,
        priority: int | None = None,
    ) -> list[AnyBinding]:
        """Return all bindings whose interface is a subclass of *cls*.

        Optionally narrows the result by *qualifier* and/or *priority*.
        The same logic is shared by both the sync and async resolution paths.

        Args:
            cls:       The base type to match against ``binding.interface``.
            qualifier: If given, only bindings with a matching qualifier are kept.
            priority:  If given, only bindings with this exact priority are kept.

        Returns:
            A (possibly empty) list of matching bindings.
        """
        from .binding import ClassBinding as _ClassBinding
        from .decorator.scope import Default as _Default
        from .metadata import _is_alternative

        # @Default is semantically equivalent to no qualifier
        if qualifier is _Default:
            qualifier = None

        return [
            b
            for b in self._bindings
            # DESIGN: _interface_matches replaces plain issubclass so that generic
            # aliases like Repository[User] are matched correctly — issubclass does
            # not accept parameterised types as its second argument.
            if _interface_matches(b.interface, cls)
            # DESIGN: exact_only bindings are self-bindings auto-generated to make
            # a concrete class resolvable by its own type.  They must NOT participate
            # in supertype sweeps (e.g. get_all(BaseClass)) because they would surface
            # every concrete subclass registered under its parent interface — creating
            # duplicates.  We allow them only when the requested type is exactly the
            # binding's interface (identity check is safe here: self-bindings are
            # always concrete classes, never generic aliases).
            and (not getattr(b, "exact_only", False) or b.interface is cls)
            and (qualifier is None or b.qualifier == qualifier)
            and (priority is None or b.priority == priority)
            # @Alternative bindings are excluded unless explicitly enabled
            and (
                not (isinstance(b, _ClassBinding) and _is_alternative(b.implementation))
                or b.implementation in self._enabled_alternatives
            )
        ]

    def is_resolvable(
        self,
        cls: type,
        *,
        qualifier: str | type | None = None,
        priority: int | None = None,
    ) -> bool:
        """Return True if at least one registered binding matches *cls*.

        A side-effect-free predicate — no instances are created or cached.
        Intended as the public counterpart to the private ``_filter()`` helper,
        so that :class:`~providify.type.InstanceProxy` and user code can guard
        optional dependencies without coupling to internal APIs.

        Args:
            cls:       The interface or concrete type to check.
            qualifier: If given, only bindings registered with this qualifier
                       are considered. ``None`` matches any qualifier.
            priority:  If given, only bindings with this exact priority are
                       considered. ``None`` accepts any priority.

        Returns:
            True  — at least one binding satisfies all conditions; calling
                    ``get(cls, qualifier=qualifier, priority=priority)``
                    will not raise ``LookupError``.
            False — no binding matches; ``get()`` would raise.

        Thread safety:  ⚠️ Conditional — safe only if ``_bindings`` is not
                        mutated concurrently.  See class-level safety note.
        Async safety:   ✅ No await points; no shared mutable state written.

        Edge cases:
            - No bindings registered at all → False.
            - qualifier narrows to zero     → False.
            - Called before first get()     → does NOT trigger validate_bindings().
            - Results are not cached — re-evaluated on every call, so a new
              binding added between two calls will be reflected immediately. ✅

        Example:
            if container.is_resolvable(Notifier, qualifier="sms"):
                svc = container.get(Notifier, qualifier="sms")
        """
        # DESIGN: delegate to _filter() which is the single source of truth for
        # binding matching logic.  _filter() is a pure list comprehension with no
        # side effects — calling it here does not trigger validation or instantiation.
        return bool(self._filter(cls, qualifier=qualifier, priority=priority))

    # ── @Alternative — deployment-time bean activation ────────────

    def enable_alternative(self, cls: type) -> None:
        """Activate an @Alternative-marked class for this container.

        Once enabled, the alternative participates in _filter() results
        and will be returned by get() / get_all() like any other binding.

        Args:
            cls: A class decorated with @Alternative.
        """
        self._enabled_alternatives.add(cls)
        self._validated = False

    def disable_alternative(self, cls: type) -> None:
        """Deactivate a previously enabled @Alternative class.

        After disabling, the alternative is excluded from resolution again.

        Args:
            cls: A class previously passed to enable_alternative().
        """
        self._enabled_alternatives.discard(cls)
        self._validated = False

    # ── Interceptor registration (F5) ────────────────────────────

    def add_interceptor(self, cls: type) -> None:
        """Register an ``@Interceptor``-decorated class to intercept matching beans.

        Interceptors are applied in registration order. The interceptor class
        must be decorated with ``@Interceptor`` and must have exactly one
        ``@AroundInvoke`` method.

        Args:
            cls: An ``@Interceptor``-decorated class.
        """
        if not _is_interceptor(cls):
            raise TypeError(f"{cls.__name__} must be decorated with @Interceptor.")
        if cls not in self._interceptor_classes:
            self._interceptor_classes.append(cls)

    def _apply_interceptors(self, instance: object, cls: type) -> object:
        """Wrap *instance* with an interceptor proxy if any interceptors apply.

        Finds interceptors whose ``@InterceptorBinding`` annotations overlap with
        those on *cls*, resolves interceptor instances, and returns an
        ``_InterceptorProxy`` wrapping the original. If no interceptors apply,
        returns *instance* unchanged.

        Args:
            instance: The fully constructed bean instance.
            cls:      The bean's implementation class.

        Returns:
            The original instance, or an ``_InterceptorProxy`` wrapping it.
        """
        if not self._interceptor_classes:
            return instance

        # Collect interceptor binding annotation types on the target class
        target_bindings: set[type] = set()
        for name in dir(cls):
            val = getattr(cls, name, None)
            if isinstance(val, type) and _is_interceptor_binding(val):
                target_bindings.add(val)

        if not target_bindings:
            return instance

        # Find interceptors that share at least one binding annotation
        chain: list[tuple[object, str]] = []
        for interceptor_cls in self._interceptor_classes:
            for name in dir(interceptor_cls):
                val = getattr(interceptor_cls, name, None)
                if isinstance(val, type) and val in target_bindings:
                    around_invoke = _get_around_invoke_method(interceptor_cls)
                    if around_invoke is not None:
                        interceptor_instance = self._resolve_constructor(
                            interceptor_cls
                        )
                        chain.append((interceptor_instance, around_invoke))
                    break

        if not chain:
            return instance

        return _InterceptorProxy(instance, chain)

    # ── Event dispatch (F7) ──────────────────────────────────────

    def _register_observers(self, instance: object, cls: type) -> None:
        """Scan *cls* for ``@Observes`` methods and register *instance* as a subscriber.

        Walks the MRO to find all ``@Observes``-decorated methods. Stores weak
        references so observer registrations don't prevent garbage collection.

        Args:
            instance: The newly created bean instance.
            cls:      The bean's implementation class.
        """
        for base in cls.__mro__:
            for name, fn in vars(base).items():
                if not callable(fn):
                    continue
                marker = _get_observes_marker(fn)
                if marker is None:
                    continue
                event_type = marker.event_type
                if event_type not in self._observers:
                    self._observers[event_type] = []
                self._observers[event_type].append(
                    (weakref.ref(instance), name, marker.is_async)
                )

    def _dispatch_event_sync(self, event: object) -> None:
        """Dispatch *event* synchronously to all registered ``@Observes`` observers.

        Delivers to observers whose registered event type is a supertype of
        ``type(event)``. Dead weak references are purged during dispatch.

        Args:
            event: The event object to dispatch.
        """
        event_type = type(event)

        for registered_type, observers in self._observers.items():
            if not issubclass(event_type, registered_type):
                continue
            live: list = []
            for ref, method_name, is_async in observers:
                inst = ref()
                if inst is None:
                    continue
                live.append((ref, method_name, is_async))
                if is_async:
                    warnings.warn(
                        f"@Observes method '{method_name}' is async — "
                        f"use EventProxy.afire() for async dispatch.",
                        stacklevel=2,
                    )
                    continue
                getattr(inst, method_name)(event)
            self._observers[registered_type] = live

    async def _dispatch_event_async(self, event: object) -> None:
        """Dispatch *event* asynchronously to all registered ``@Observes`` observers.

        Awaits async observer methods; calls sync ones normally. Dead weak
        references are purged during dispatch.

        Args:
            event: The event object to dispatch.
        """
        event_type = type(event)

        for registered_type, observers in self._observers.items():
            if not issubclass(event_type, registered_type):
                continue
            live: list = []
            for ref, method_name, is_async in observers:
                inst = ref()
                if inst is None:
                    continue
                live.append((ref, method_name, is_async))
                bound = getattr(inst, method_name)
                if is_async:
                    await bound(event)
                else:
                    bound(event)
            self._observers[registered_type] = live

    # ── DEPENDENT scope flush (F10) ──────────────────────────────

    def flush_dependents(self) -> None:
        """Call ``@PreDestroy`` on all tracked DEPENDENT-scoped instances and clear them.

        Only instances created by classes decorated with ``@Component(track=True)``
        (or any scoping decorator with ``track=True``) are tracked and flushed.

        Raises:
            RuntimeError: If any @PreDestroy is ``async def`` — use ``aflush_dependents()``.
        """
        for instance in self._tracked_dependents:
            cls = type(instance)
            binding = next(
                (
                    b
                    for b in self._bindings
                    if isinstance(b, ClassBinding) and b.implementation is cls
                ),
                None,
            )
            if binding is None or binding.pre_destroy is None:
                continue
            if binding.pre_destroy.is_async:
                raise RuntimeError(
                    f"@PreDestroy on '{cls.__name__}' is async — "
                    f"use await container.aflush_dependents() instead."
                )
            getattr(instance, binding.pre_destroy.fn_name)()
        self._tracked_dependents.clear()

    async def aflush_dependents(self) -> None:
        """Async variant of :meth:`flush_dependents`.

        Awaits async ``@PreDestroy`` hooks; calls sync ones normally.
        """
        for instance in self._tracked_dependents:
            cls = type(instance)
            binding = next(
                (
                    b
                    for b in self._bindings
                    if isinstance(b, ClassBinding) and b.implementation is cls
                ),
                None,
            )
            if binding is None or binding.pre_destroy is None:
                continue
            bound = getattr(instance, binding.pre_destroy.fn_name)
            if binding.pre_destroy.is_async:
                await bound()
            else:
                bound()
        self._tracked_dependents.clear()

    # ── Scope utilities (F14) ────────────────────────────────────

    def run_in_request(self, fn: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
        """Execute *fn* inside a request scope, returning its result.

        Args:
            fn:     A sync callable to execute.
            *args:  Positional arguments forwarded to *fn*.
            **kwargs: Keyword arguments forwarded to *fn*.

        Returns:
            The return value of *fn*.
        """
        with self.request():
            return fn(*args, **kwargs)

    async def arun_in_request(
        self, fn: Callable[..., Any], *args: Any, **kwargs: Any
    ) -> Any:
        """Execute *fn* inside an async request scope, returning its result.

        Args:
            fn:     An async callable to execute.
            *args:  Positional arguments forwarded to *fn*.
            **kwargs: Keyword arguments forwarded to *fn*.

        Returns:
            The awaited return value of *fn*.
        """
        async with self.arequest():
            return await fn(*args, **kwargs)

    def run_in_session(
        self, session_id: str, fn: Callable[..., Any], *args: Any, **kwargs: Any
    ) -> Any:
        """Execute *fn* inside a session scope identified by *session_id*.

        Args:
            session_id: The session identifier.
            fn:         A sync callable to execute.
            *args:      Positional arguments forwarded to *fn*.
            **kwargs:   Keyword arguments forwarded to *fn*.

        Returns:
            The return value of *fn*.
        """
        with self.session(session_id):
            return fn(*args, **kwargs)

    async def arun_in_session(
        self, session_id: str, fn: Callable[..., Any], *args: Any, **kwargs: Any
    ) -> Any:
        """Execute *fn* inside an async session scope identified by *session_id*.

        Args:
            session_id: The session identifier.
            fn:         An async callable to execute.
            *args:      Positional arguments forwarded to *fn*.
            **kwargs:   Keyword arguments forwarded to *fn*.

        Returns:
            The awaited return value of *fn*.
        """
        async with self.asession(session_id):
            return await fn(*args, **kwargs)

    def _filter_singleton(
        self,
        qualifier: str | type | None = None,
        priority: int | None = None,
    ) -> list[AnyBinding]:
        """Return all SINGLETON-scoped bindings, optionally filtered.

        Args:
            qualifier: If given, only bindings with this exact qualifier are returned.
            priority:  If given, only bindings with this exact priority are returned.

        Returns:
            A new list containing only the bindings that satisfy all conditions.

        Edge cases:
            - qualifier=None and priority=None → returns all SINGLETON bindings.
            - No bindings match               → returns an empty list.

        Thread safety:  ⚠️ Conditional — safe only if self._bindings is not mutated
                        concurrently.
        Async safety:   ✅ No await points, no shared mutable state written.
        """
        return [
            b
            for b in self._bindings
            if b.scope == Scope.SINGLETON
            and (qualifier is None or b.qualifier == qualifier)
            and (priority is None or b.priority == priority)
        ]

    def _get_best_candidate(
        self,
        cls: type[T],
        qualifier: str | type | None = None,
        priority: int | None = None,
    ) -> AnyBinding:
        """Return the highest-priority binding for the requested type.

        Args:
            cls:       The interface or concrete type to resolve.
            qualifier: Named qualifier to filter bindings. ``None`` matches any.
            priority:  Exact priority to match. ``None`` returns the best available.

        Returns:
            The highest-priority-value binding among all matching candidates
            (higher value = higher precedence).

        Raises:
            LookupError: No binding is registered for ``cls`` with the given
                         qualifier and priority.
        """
        candidates = self._filter(cls, qualifier=qualifier, priority=priority)
        if not candidates:
            raise LookupError(
                f"No binding found for '{_type_name(cls)}'"
                + (f" qualifier={qualifier!r}" if qualifier else "")
                + ". Did you forget container.bind() or container.provide()?"
            )
        return max(candidates, key=lambda b: b.priority)

    # ── Cache helpers ─────────────────────────────────────────────

    def _get_cache(self, binding: AnyBinding) -> dict[Any, object] | None:
        """Return the instance cache that corresponds to *binding*'s scope.

        Args:
            binding: The binding whose ``scope`` attribute is inspected.

        Returns:
            - The singleton cache dict for ``Scope.SINGLETON``.
            - The active request-scope cache dict for ``Scope.REQUEST``.
            - The active session-scope cache dict for ``Scope.SESSION``.
            - ``None`` for ``Scope.DEPENDENT`` — no caching, new instance every time.

        Raises:
            RuntimeError: If the binding is ``REQUEST`` or ``SESSION`` scoped but
                no matching scope context is currently active.
        """
        match binding.scope:
            case Scope.SINGLETON:
                return self._singleton_cache

            case Scope.REQUEST:
                cache = self.scope_context.get_request_cache()
                if cache is None:
                    raise RuntimeError(
                        f"Cannot resolve @RequestScoped '{_type_name(binding.interface)}' "
                        f"outside of an active request context. "
                        f"Use: with container.request(): ..."
                        f" or async with container.arequest(): ..."
                    )
                return cache

            case Scope.SESSION:
                cache = self.scope_context.get_session_cache()
                if cache is None:
                    raise RuntimeError(
                        f"Cannot resolve @SessionScoped '{_type_name(binding.interface)}' "
                        f"outside of an active session context. "
                        f"Use: with container.session(...): ..."
                        f" or async with container.asession(...): ..."
                    )
                return cache

            case _:
                # DEPENDENT — no cache, new instance every time
                return None

    def _get_cache_key(self, binding: AnyBinding) -> Any:
        """Return a hashable cache key for *binding*.

        Uses the implementation class for :class:`~providify.binding.ClassBinding`
        and the provider callable for :class:`~providify.binding.ProviderBinding`,
        so the key is stable and unique regardless of binding type.

        Args:
            binding: The binding to derive a key for.

        Returns:
            The concrete class (``type``) or provider function (``Callable``).
        """
        if isinstance(binding, ClassBinding):
            return binding.implementation
        return binding.fn

    def _check_singleton_reentry(self, binding: AnyBinding, key: Any) -> None:
        """Raise if this thread/task is already creating the singleton *key*.

        Both singleton paths hold a non-reentrant per-key lock across
        ``create()`` / ``acreate()``. If that call resolves back to the same
        binding, re-acquiring the lock would block forever on a lock the
        caller already owns — and the cycle detection that runs inside
        ``create()`` would never be reached. This converts that hang into the
        same :class:`CircularDependencyError` the DEPENDENT path already
        raises, at the point where the cycle is actually detectable.

        Args:
            binding: The binding about to be instantiated — used only to name
                     the offending component in the error message.
            key:     Its singleton cache key (from :meth:`_get_cache_key`).

        Returns:
            None — returns silently when no re-entry is in progress.

        Raises:
            CircularDependencyError: When *key* is already being created in
                the current context, with the resolution chain in the message.

        Thread safety:  ✅ Reads a ``ContextVar`` private to this thread; a
                        different thread waiting on the per-key lock has its
                        own empty set and is never affected.
        Async safety:   ✅ Each ``asyncio.Task`` inherits its own copy, so
                        concurrent tasks cannot see each other's in-progress
                        keys.

        Edge cases:
            - Same key, different container → different ``id(self)``, so no
              false positive.
            - ``create()`` raised on a previous attempt → the key was reset in
              a ``finally``, so a retry is not mistaken for a cycle.
        """
        if (id(self), key) not in _singleton_in_progress.get():
            return

        # The resolution stack was pushed by _resolve_constructor / _call_provider
        # inside create(), so it already names the component we re-entered.
        owner = getattr(binding, "implementation", None) or binding.interface
        name = _type_name(owner)
        raise CircularDependencyError(
            f"{_format_cycle(_current_stack(), owner)}\n"
            f"The singleton '{name}' requested itself while it was still being "
            f"created — its own constructor or provider resolved back to its own "
            f"binding. A common cause is a parameter annotated with a type that "
            f"matches every binding: a bare 'object' (or 'object | None') is a "
            f"supertype of all of them, including this one."
        )

    # ── Instantiation ─────────────────────────────────────────────

    def _instantiate_sync(self, binding: AnyBinding) -> Any:
        """Instantiate *binding* synchronously, respecting scope caching.

        For SINGLETON scope, uses per-key double-check locking to guarantee
        exactly one instance is created under concurrent access from multiple
        threads.

        Pattern (singleton path only):
            1. Check cache without lock — fast path for already-cached singletons.
            2. Lazy-create a per-key threading.Lock (under guard lock).
            3. Check cache again inside the per-key lock — another thread may
               have won the race between steps 1 and 2.
            4. Create instance and store under the per-key lock.

        For REQUEST/SESSION scope, the ContextVar isolation guarantees that each
        task sees its own cache — no additional locking is needed.
        For DEPENDENT scope, no cache exists — a new instance is always created.

        Args:
            binding: The binding to instantiate.

        Returns:
            The (possibly cached) resolved instance.

        Thread safety:  ✅ SINGLETON: double-check lock ensures one creation.
                        REQUEST/SESSION: ContextVar-isolated — no shared state.
                        DEPENDENT: no cache — concurrent calls each get a new instance.
        Async safety:   ✅ No await points — safe to call from sync code.

        Edge cases:
            - binding.create() raises → no cache entry is stored (exception propagates).
            - Two threads race on a cold singleton key → guard lock serialises
              lock creation; per-key lock serialises instance creation.
            - The singleton's own create() resolves back to this same key on this
              same thread → ``CircularDependencyError`` from
              :meth:`_check_singleton_reentry`. The per-key lock is not
              reentrant, so without that guard the call would block forever on a
              lock it already holds.
        """
        key = self._get_cache_key(binding)
        cache = self._get_cache(binding)

        # ── Fast path: already in cache (no lock needed) ─────────────────────
        if cache is not None and key in cache:
            return cache[key]

        # ── SINGLETON double-check locking ────────────────────────────────────
        # Only apply per-key locking for the singleton cache.  REQUEST/SESSION
        # caches are per-context (ContextVar) so concurrent tasks cannot share
        # them; DEPENDENT has no cache at all.
        if cache is self._singleton_cache:
            # Re-entrancy guard — MUST run before acquiring the per-key lock.
            # If this thread is already inside create() for this key, taking
            # the lock again would block forever on a lock we ourselves hold
            # (threading.Lock is not reentrant), and the cycle detection that
            # lives inside create() would never get to run.
            self._check_singleton_reentry(binding, key)

            # Lazy-create the per-key lock under the guard lock to prevent
            # two threads from each creating a different lock object for the
            # same key — only the first one must be used.
            with self._singleton_lock_guard:
                if key not in self._singleton_locks:
                    self._singleton_locks[key] = threading.Lock()
            per_key_lock = self._singleton_locks[key]

            with per_key_lock:
                # Second check inside the lock: another thread may have already
                # created and cached the instance between our first check and
                # acquiring this lock.
                if key in cache:
                    return cache[key]
                token = _singleton_in_progress.set(
                    _singleton_in_progress.get() | {(id(self), key)}
                )
                try:
                    instance = binding.create(self)
                    if isinstance(binding, ClassBinding):
                        self._register_observers(instance, binding.implementation)
                        instance = self._apply_interceptors(
                            instance, binding.implementation
                        )
                    cache[key] = instance
                finally:
                    # Reset even when create() raises: the failed key must not
                    # stay marked in-progress, or a later retry in the same
                    # context would report a phantom cycle.
                    _singleton_in_progress.reset(token)
            return instance

        # ── Non-singleton path (REQUEST, SESSION, DEPENDENT) ─────────────────
        instance = binding.create(self)
        if isinstance(binding, ClassBinding):
            self._register_observers(instance, binding.implementation)
            instance = self._apply_interceptors(instance, binding.implementation)
        if cache is not None:
            cache[key] = instance
        elif isinstance(binding, ClassBinding):
            # DEPENDENT scope: track if requested
            meta = _get_metadata(binding.implementation)
            if meta is not None and meta.track:
                self._tracked_dependents.append(instance)
        return instance

    async def _instantiate_async(self, binding: AnyBinding) -> Any:
        """Instantiate *binding* asynchronously, respecting scope caching.

        Mirrors :meth:`_instantiate_sync` but delegates to ``binding.acreate()``.
        For SINGLETON scope, uses per-key asyncio.Lock double-check locking —
        the same pattern as the sync path but with asyncio primitives so the
        event loop is never blocked.

        asyncio.Lock objects are created lazily inside this method (never at
        module level or ``__init__``) because they require a running event loop.

        Args:
            binding: The binding to instantiate.

        Returns:
            The (possibly cached) resolved instance.

        Async safety:   ✅ SINGLETON: asyncio.Lock ensures one creation per key
                        per event loop.  REQUEST/SESSION: ContextVar-isolated.
                        DEPENDENT: no cache — each awaiter gets a fresh instance.

        Edge cases:
            - binding.acreate() raises → no cache entry is stored.
            - Two concurrent tasks race on a cold singleton key → the asyncio.Lock
              serialises them; only one runs acreate().
            - The singleton's own acreate() awaits this same key from this same
              task → ``CircularDependencyError`` from
              :meth:`_check_singleton_reentry`; ``asyncio.Lock`` is not reentrant
              either, so the await would otherwise never complete.
        """
        key = self._get_cache_key(binding)
        cache = self._get_cache(binding)

        # ── Fast path ─────────────────────────────────────────────────────────
        if cache is not None and key in cache:
            return cache[key]

        # ── SINGLETON double-check locking (async) ────────────────────────────
        if cache is self._singleton_cache:
            # Re-entrancy guard — see _instantiate_sync. asyncio.Lock is no more
            # reentrant than threading.Lock: a singleton whose acreate() awaits
            # its own resolution would await a lock its own task already holds,
            # which never completes.
            self._check_singleton_reentry(binding, key)

            # Lazy-create asyncio.Lock under the threading guard lock.
            # DESIGN: the guard lock is a threading.Lock here (not asyncio.Lock)
            # because asyncio.Lock cannot be created outside an event loop and
            # we only need it for a very brief dict-check + insert — no I/O.
            # The window is tiny; the risk of blocking the loop is negligible.
            with self._singleton_lock_guard:
                if key not in self._async_singleton_locks:
                    # Created lazily — requires a running loop ✅
                    self._async_singleton_locks[key] = asyncio.Lock()
            async_lock = self._async_singleton_locks[key]

            async with async_lock:
                if key in cache:
                    return cache[key]
                token = _singleton_in_progress.set(
                    _singleton_in_progress.get() | {(id(self), key)}
                )
                try:
                    instance = await binding.acreate(self)
                    if isinstance(binding, ClassBinding):
                        self._register_observers(instance, binding.implementation)
                        instance = self._apply_interceptors(
                            instance, binding.implementation
                        )
                    cache[key] = instance  # type: ignore[index]
                finally:
                    # Reset even when acreate() raises — see _instantiate_sync.
                    _singleton_in_progress.reset(token)
            return instance

        # ── Non-singleton path ────────────────────────────────────────────────
        instance = await binding.acreate(self)
        if isinstance(binding, ClassBinding):
            self._register_observers(instance, binding.implementation)
            instance = self._apply_interceptors(instance, binding.implementation)
        if cache is not None:
            cache[key] = instance
        elif isinstance(binding, ClassBinding):
            meta = _get_metadata(binding.implementation)
            if meta is not None and meta.track:
                self._tracked_dependents.append(instance)
        return instance

    # ── Type-hint resolution ──────────────────────────────────────

    def _is_resolvable(self, hint: Any) -> bool:
        """Return ``True`` if at least one binding's interface satisfies *hint*.

        Accepts both concrete types and parameterised generic aliases.

        Args:
            hint: The type or generic alias to check.

        Returns:
            ``True`` if a matching binding exists, ``False`` otherwise.
        """
        # _interface_matches replaces issubclass — handles generic aliases safely
        return any(_interface_matches(b.interface, hint) for b in self._bindings)

    def _invalidate_type_caches(self) -> None:
        """Discard every cache whose contents depend on the current binding set.

        `_localns_cache` and `_hints_cache` (plan §7.4) must die TOGETHER:
        every value in `_hints_cache` was resolved using the localns
        `_build_localns()` produced at the time, so a stale `_hints_cache`
        entry surviving a `_localns_cache` rebuild would silently serve
        pre-mutation hints (e.g. a parameter that was unresolvable-and-
        skipped before a new `bind()` call, wrongly staying skipped after).

        This is the ONE place both caches are cleared — every call site that
        used to write ``self._localns_cache = None`` directly (``bind()``,
        ``register()``, ``provide()``, ``reset_binding()``, ``copy()``, and
        ``scanner.py``'s external poke into the container's private state)
        now calls this method instead, so a future third cache has exactly
        one place to be added — no "forgot the seventh site" bug.

        Thread safety:  ⚠️ Same caveat as `_build_localns` — no lock. Two
                        threads invalidating concurrently both end up with
                        empty caches; the next resolution on either thread
                        rebuilds from the (now-consistent) binding list. The
                        window this closes is "stale hints survive a binding
                        change", not "no data race" — the container's binding
                        mutation itself is not documented as thread-safe post
                        first resolution (see class docstring).

        Returns:
            None
        """
        self._localns_cache = None
        self._hints_cache.clear()

    def _build_localns(self) -> dict[str, type]:
        """Return a cached ``localns`` dict for use with ``get_type_hints()``.

        Maps every registered interface (and ClassBinding implementation) to its
        class name, so that PEP-563 string annotations that reference locally-
        defined types (e.g. classes defined inside test functions) can be
        evaluated even when those types are absent from the function's module
        globals.

        Caching strategy:
            The dict is built lazily on first use and stored in
            ``self._localns_cache``. ``bind()``, ``register()``, and
            ``provide()`` each set ``_localns_cache = None`` so the dict is
            rebuilt after any binding change. In the common pattern — all
            bindings registered before the first ``get()`` call — the dict is
            built exactly once.

        Thread safety:  ⚠️ Conditional — the cache is not protected by a lock.
                        Two threads resolving concurrently before the first
                        cached build may each build the dict independently;
                        the last write wins. Both builds produce identical
                        results, so correctness is preserved.

        Edge cases:
            - A binding whose ``interface`` is not a type or generic alias
              (e.g. corrupted by external mutation) is skipped with a
              ``logger.warning`` rather than raising — this namespace is
              shared by every resolution in the container, so one malformed
              binding must never abort construction for all the others.

        Returns:
            A ``dict[str, type]`` mapping class ``__name__`` → class object.
        """
        if self._localns_cache is None:
            localns: dict[str, type] = {}
            for b in self._bindings:
                # Interface — what callers annotate against (e.g. Repository).
                # For generic aliases (Repository[User]), __name__ does not exist;
                # map the origin type (Repository) instead so string annotations
                # like "Repository" in PEP-563 deferred mode still resolve.
                iface_origin = get_origin(b.interface)
                iface_key = iface_origin if iface_origin is not None else b.interface
                # WHY the getattr guard: this namespace is CONTAINER-WIDE, so an
                # unhandled AttributeError here silently zeroes the type hints of
                # every other binding (the original forward-reference bug).  One
                # malformed interface must cost only itself.
                iface_name = getattr(iface_key, "__name__", None)
                if iface_name is None:
                    logger.warning(
                        "Skipping binding with non-type interface %r while building "
                        "the type-hint namespace; its dependents may fail to resolve.",
                        b.interface,
                    )
                else:
                    localns[iface_name] = iface_key  # type: ignore[assignment]
                if isinstance(b, ClassBinding):
                    # Implementation — annotations may reference the concrete
                    # class directly rather than the abstract interface.
                    localns[b.implementation.__name__] = b.implementation

                    # Also add any generic origin types and their type arguments
                    # from the implementation's __orig_bases__.
                    #
                    # DESIGN: PEP-563 (from __future__ import annotations) makes
                    # ALL annotations lazy strings.  When a caller annotates a
                    # parameter as `repo: Repository[User]`, the string
                    # `"Repository[User]"` must be eval'd by get_type_hints().
                    # That eval needs both `Repository` (the generic class) and
                    # `User` (the type argument) in the namespace.
                    #
                    # These are often locally-defined types that are absent from
                    # fn.__globals__, so we harvest them here from the MRO of
                    # each registered implementation — the only place where the
                    # full parameterised form is preserved.
                    for base in getattr(b.implementation, "__orig_bases__", ()):
                        origin = get_origin(base)
                        if origin is not None and isinstance(origin, type):
                            localns[origin.__name__] = origin
                        for arg in get_args(base):
                            if isinstance(arg, type):
                                localns[arg.__name__] = arg
            self._localns_cache = localns
        return self._localns_cache

    def _resolve_params(
        self,
        target: Callable[..., Any],
        owner_name: str,
        *,
        owner: type | None = None,
    ) -> dict[str, Any]:
        """Resolve *target*'s parameters one at a time — the Phase-7 replacement for both Tier-1/2 whole-signature helpers.

        Delegates to :func:`providify._annotations.resolve_params`, which
        evaluates each parameter's annotation in isolation so that one
        unresolvable, non-injected parameter can no longer wipe out every
        other parameter's hints (the false positive both
        ``_resolve_hints_or_warn`` and ``_resolve_hints_or_raise`` used to
        paper over from opposite ends). Replaces both of those release-A
        helpers — one resolver, two callers (the injection path and the
        validation path), because the "raise vs. skip" decision is now made
        PER PARAMETER by :func:`resolve_params` itself, not by the caller's
        choice of helper.

        Caching:
            Keyed by *target* itself (the callable object — see
            :attr:`_hints_cache`'s definition in ``__init__`` for why NOT
            ``id(target)`` or a ``WeakKeyDictionary``). A cache hit returns a
            SHALLOW COPY so a caller mutating the returned dict (several do,
            e.g. ``hints.pop(...)`` historically) can never corrupt the
            cached entry for the next resolution.  Only successes are
            cached — a failure re-raises fresh every time rather than
            replaying a exception with a stale traceback.

        Thread safety:  ✅ Safe without a lock. Every cache value is a pure
                        function of ``(target, self._bindings)`` — a race
                        between two threads recomputes IDENTICAL data, and
                        plain ``dict`` item assignment is atomic under the
                        GIL, so no torn read/write is possible. The one
                        mutable hazard (a caller editing its returned dict)
                        is eliminated by the copy-on-read above, not by a
                        lock — see plan 001 §7.4.
        Async safety:   ✅ Safe — no ``await`` inside resolution; sync and
                        async callers share one cache with no special
                        casing needed.

        Args:
            target:     The callable whose parameters are resolved —
                        typically ``cls.__init__`` or a provider function.
            owner_name: Human-readable name embedded in any raised error.
            owner:      The class that declares *target* as a method, for
                        PEP-695 ``__type_params__`` seeding — forwarded to
                        :func:`providify._annotations._annotation_namespaces`.

        Returns:
            ``dict[param_name -> resolved hint]`` — a fresh copy on every
            call, safe for the caller to mutate.

        Raises:
            AnnotationResolutionError: A parameter's annotation IS (or
                plausibly is) an injection point but cannot be evaluated —
                naming both *owner_name* and the specific parameter.
        """
        cached = self._hints_cache.get(target)
        if cached is not None:
            return dict(cached)

        globalns, localns = _annotation_namespaces(
            target, self._build_localns(), owner=owner
        )
        hints = resolve_params(target, owner_name, globalns, localns)
        self._hints_cache[target] = hints
        return dict(hints)

    def _resolve_class_annotations(self, cls: type) -> dict[str, Any]:
        """Resolve *cls*'s class-level annotations one at a time (Phase-7 replacement).

        Delegates to :func:`providify._annotations.resolve_class_annotations`,
        which walks the full MRO and evaluates each attribute's annotation in
        isolation. Replaces the release-A pairing of
        ``_resolve_hints_or_warn`` (Tier-1, ``_inject_class_vars_sync/async``)
        and ``_resolve_hints_or_raise`` (Tier-2, ``_collect_class_var_hints``)
        for this target kind — per-attribute resolution makes both policies
        the SAME function, because an unresolvable annotation is now either
        an injection point (raise, naming the attribute) or not (silently
        omitted) regardless of which caller asked.

        Caching:            Keyed by *cls* itself; see :meth:`_resolve_params`
                             — identical strategy (copy-on-read, success-only
                             caching, shared ``_hints_cache``).
        Thread/async safety: Identical rationale to :meth:`_resolve_params`.

        Args:
            cls: The class whose (and whose ancestors') class-level
                 annotations are resolved.

        Returns:
            ``dict[attr_name -> resolved hint]`` — a fresh copy on every call.

        Raises:
            AnnotationResolutionError: A class attribute's annotation IS (or
                plausibly is) an injection point but cannot be evaluated —
                naming the declaring class and the attribute.
        """
        cached = self._hints_cache.get(cls)
        if cached is not None:
            return dict(cached)

        hints = resolve_class_annotations(cls, self._build_localns())
        self._hints_cache[cls] = hints
        return dict(hints)

    def _collect_kwargs_sync(
        self,
        fn: Callable[..., Any],
        owner_name: str,
    ) -> dict[str, Any]:
        """Build a ``kwargs`` dict by resolving every providify parameter of *fn*.

        Iterates over the type hints of *fn*, skips ``return``, and tries to
        resolve each annotated parameter from the container. Parameters with
        no binding are skipped if they have a default value, or raise otherwise.

        Shared by :meth:`_resolve_constructor` and :meth:`_call_provider`.

        Args:
            fn:         The callable whose parameters should be resolved.
            owner_name: A human-readable name used in error messages.

        Returns:
            A dict mapping parameter names to resolved instances.
            Parameters that have a default and no binding are omitted.

        Raises:
            LookupError: If a required parameter (no default) cannot be resolved.
            AnnotationResolutionError: A parameter's annotation IS (or
                plausibly is) an injection point but cannot be evaluated —
                see :meth:`_resolve_params`. Unresolvable annotations on
                parameters that are NOT injection points no longer affect
                this call at all (Phase 7 — per-parameter resolution).
        """
        hints = self._resolve_params(fn, owner_name)

        sig = inspect.signature(fn)
        resolved: dict[str, Any] = {}

        # Declaring class for InjectionPoint — outermost class on the resolution stack.
        declaring_class = _current_stack()[-1] if _current_stack() else None

        for param_name, hint in hints.items():
            param = sig.parameters.get(param_name)
            # Build InjectionPoint context so InjectionPoint-typed params resolve correctly.
            ip = InjectionPoint(
                declaring_class=declaring_class,
                param_name=param_name,
                qualifier=None,
                annotation=hint,
            )
            ip_token = _current_injection_point.set(ip)
            try:
                resolved_value = self._resolve_hint_sync(hint, param_name, owner_name)
            finally:
                _current_injection_point.reset(ip_token)

            if resolved_value is _UNRESOLVED:
                # No binding found — use default or fail
                if param and param.default is inspect.Parameter.empty:
                    raise LookupError(
                        f"Cannot resolve '{param_name}: {hint}' in '{owner_name}'. "
                        f"Bind it or provide a default value."
                    )
            else:
                resolved[param_name] = resolved_value

        return resolved

    async def _collect_kwargs_async(
        self,
        fn: Callable[..., Any],
        owner_name: str,
    ) -> dict[str, Any]:
        """Build a ``kwargs`` dict by resolving every providify parameter, asynchronously.

        Async mirror of :meth:`_collect_kwargs_sync`.
        Shared by :meth:`_resolve_constructor_async` and :meth:`_call_provider_async`.

        Args:
            fn:         The callable whose parameters should be resolved.
            owner_name: A human-readable name used in error messages.

        Returns:
            A dict mapping parameter names to resolved instances.

        Raises:
            LookupError: If a required parameter (no default) cannot be resolved.
            AnnotationResolutionError: See :meth:`_collect_kwargs_sync` —
                identical policy, async mirror.
        """
        hints = self._resolve_params(fn, owner_name)

        sig = inspect.signature(fn)
        resolved: dict[str, Any] = {}

        declaring_class = _current_stack()[-1] if _current_stack() else None

        for param_name, hint in hints.items():
            param = sig.parameters.get(param_name)
            ip = InjectionPoint(
                declaring_class=declaring_class,
                param_name=param_name,
                qualifier=None,
                annotation=hint,
            )
            ip_token = _current_injection_point.set(ip)
            try:
                resolved_value = await self._resolve_hint_async(
                    hint, param_name, owner_name
                )
            finally:
                _current_injection_point.reset(ip_token)

            if resolved_value is _UNRESOLVED:
                if param and param.default is inspect.Parameter.empty:
                    raise LookupError(
                        f"Cannot resolve '{param_name}: {hint}' in '{owner_name}'. "
                        f"Bind it or provide a default value."
                    )
            else:
                resolved[param_name] = resolved_value

        return resolved

    def _collect_dependencies(
        self,
        fn: Callable[..., Any],
        qualifier: str | type | None = None,
        priority: int | None = None,
    ) -> list[AnyBinding]:
        """Introspect a callable's type hints and resolve each to a registered binding.

        Only hints that carry providify metadata produce a binding — plain
        ``int``, ``str``, unannotated args, and the ``return`` hint are skipped.

        Args:
            fn:        The callable whose parameter annotations are inspected.
                       Typically ``cls.__init__`` or a provider function.
            qualifier: Forwarded to ``_resolve_dependency``.
            priority:  Forwarded to ``_resolve_dependency``.

        Returns:
            Ordered list of ``AnyBinding`` objects, one per resolvable providify
            parameter. Parameters that are unresolvable or lack providify metadata
            are silently omitted.

        Edge cases:
            - A parameter that IS an injection point but cannot be resolved
              (``AnnotationResolutionError`` from :meth:`_resolve_params`) →
              swallowed **and logged**; every OTHER parameter that DID
              resolve is still included — Phase 7 yields a partial graph
              here instead of the whole-signature ``[]`` release A produced.
            - No providify parameters → returns ``[]``.
        """
        try:
            hints = self._resolve_params(fn, getattr(fn, "__qualname__", str(fn)))
        except AnnotationResolutionError as exc:
            # Tier 3 — advisory/reporting path (dependency-graph construction).
            # A partial or missing graph node is a worse debugging experience,
            # not a wiring bug, so the failure is swallowed — but it must never
            # be silent, or the gap in the graph looks like "no dependencies"
            # rather than "couldn't tell". Per-parameter resolution means this
            # only fires for a parameter that IS an injection point — every
            # OTHER parameter on *fn* already resolved fine independently, so
            # in practice this now only ever loses ONE dependency, not all of them.
            logger.warning(
                "Dependency graph for '%s' is incomplete — cannot resolve type hints (%s).",
                getattr(fn, "__qualname__", fn),
                exc,
            )
            hints = {}

        dependencies: list[AnyBinding] = []

        for _, hint in hints.items():
            resolved_dep = self._resolve_dependency(
                hint, qualifier=qualifier, priority=priority
            )
            if resolved_dep is not None:
                dependencies.append(resolved_dep)
        return dependencies

    def _resolve_dependency(
        self,
        hint: Any,
        qualifier: str | type | None = None,
        priority: int | None = None,
    ) -> AnyBinding | None:
        """Attempt to resolve a single type hint to its best-matching binding.

        Args:
            hint:      A single resolved type hint, possibly ``Annotated[T, ...]``.
            qualifier: Filters candidates to those matching this qualifier.
            priority:  Restricts to candidates matching this exact priority.

        Returns:
            The best ``AnyBinding`` for the hint's base type, or ``None`` if:
            - the hint has no providify metadata, **or**
            - ``_get_best_candidate`` raises ``LookupError``.

        Edge cases:
            - Bare type with no ``Annotated`` wrapper → ``None`` returned.
            - ``LookupError`` from ``_get_best_candidate`` → swallowed, returns ``None``.
        """
        if not _has_providify_metadata(hint):
            return None
        args = get_args(hint)
        base_type = args[0]
        try:
            return self._get_best_candidate(
                base_type, qualifier=qualifier, priority=priority
            )
        except LookupError:
            return None

    def _resolve_hint_sync(self, hint: Any, param_name: str, owner_name: str) -> Any:
        """Resolve a single type hint to an instance, synchronously.

        Handles four cases:
        - ``Annotated[T, LazyMeta(...)]``        — returns a :class:`LazyProxy`.
        - ``Annotated[T, InjectMeta(all=True)]`` — resolves every matching binding as a list.
        - ``Annotated[T, InjectMeta(...)]``       — resolves T with optional qualifier/priority.
        - Plain type with a registered binding    — resolved via :meth:`get`.
        - Everything else                         — returns :data:`_UNRESOLVED`.

        Args:
            hint:       The raw type hint (possibly ``Annotated``).
            param_name: Parameter name, used only for error messages.
            owner_name: Class or function name, used only for error messages.

        Returns:
            The resolved instance, or :data:`_UNRESOLVED` if no binding matches.
        """
        if get_origin(hint) is Annotated:
            args = get_args(hint)
            base_type = args[0]

            # ── Detect Optional[T] / T | None inside the Inject/Live/Lazy wrapper ──
            # Handles: Inject[Optional[T]], Inject[T | None],
            #          Live[Optional[T]],   Live[T | None],
            #          Lazy[Optional[T]],   Lazy[T | None].
            #
            # When the user writes Inject[T | None], the runtime expansion is
            # Annotated[T | None, InjectMeta()].  base_type is then the union
            # T | None, NOT a registered concrete type — so self.get(T | None)
            # would always raise LookupError.  _unwrap_union unwraps it to T
            # and signals that None should be returned when the binding is absent.
            #
            # DESIGN: only simplify for exactly ONE non-None candidate, i.e. a
            # true Optional[T].  Multi-type unions (Inject[T1 | T2 | None]) are
            # passed through unchanged — the caller can spell that as a plain
            # T1 | T2 | None annotation outside of Inject/Live/Lazy, which the
            # existing Union-branch below already handles correctly.
            _base_union = _unwrap_union(base_type)
            if (
                _base_union is not None
                and len(_base_union[0]) == 1
                and _base_union[1]  # NoneType was present → truly optional
            ):
                # Simple Optional[T]: replace the union with its sole inner type
                # and mark the whole annotation as optional.
                effective_base_type: Any = _base_union[0][0]
                effective_optional: bool = True
            else:
                # Not an Optional inside a wrapper — resolve as-is.
                effective_base_type = base_type
                effective_optional = False

            # Priority order: LiveMeta → LazyMeta → InstanceMeta → InjectMeta.
            # A hint can only carry one _providify marker at a time, but we
            # check in this order so the most specific proxy type wins.
            live_meta = next((a for a in args[1:] if isinstance(a, LiveMeta)), None)
            lazy_meta = next((a for a in args[1:] if isinstance(a, LazyMeta)), None)
            instance_meta = next(
                (a for a in args[1:] if isinstance(a, InstanceMeta)), None
            )
            inject_meta = next((a for a in args[1:] if isinstance(a, InjectMeta)), None)

            if live_meta:
                # Return a LiveProxy — re-resolves on every .get() call.
                # Correct for REQUEST/SESSION scoped deps held by longer-lived components.
                # Merge optionality from the type annotation (T | None) with the
                # explicit LiveMeta.optional field so both spell-forms work.
                return LiveProxy(
                    self,
                    effective_base_type,
                    qualifier=live_meta.qualifier,
                    priority=live_meta.priority,
                    optional=effective_optional or live_meta.optional,
                )
            elif lazy_meta:
                # Return a proxy now — actual resolution is deferred to .get() call time.
                # This breaks circular dependency cycles: both constructors return before
                # either dependency is resolved, so the stack never sees a cycle.
                # Merge optionality from the type annotation with LazyMeta.optional.
                return LazyProxy(
                    self,
                    effective_base_type,
                    qualifier=lazy_meta.qualifier,
                    priority=lazy_meta.priority,
                    optional=effective_optional or lazy_meta.optional,
                )
            elif instance_meta:
                # Return an InstanceProxy — gives the owner full control: .get() for
                # a single best-priority instance, .get_all() for all matches,
                # .resolvable() for an optional guard.  No resolution happens here.
                # Qualifier/priority are NOT baked in at construction — the caller
                # passes them at call time on get() / get_all() / resolvable().
                return InstanceProxy(self, effective_base_type)
            elif inject_meta and inject_meta.all:
                inner = (
                    get_args(effective_base_type)[0]
                    if get_origin(effective_base_type) is list
                    else effective_base_type
                )
                return self.get_all(inner, qualifier=inject_meta.qualifier)
            elif inject_meta:
                # Merge optionality: type-annotation form (T | None) OR explicit
                # InjectMeta(optional=True) — both should inject None when absent.
                is_optional = inject_meta.optional or effective_optional
                try:
                    return self.get(
                        effective_base_type,
                        qualifier=inject_meta.qualifier,
                        priority=inject_meta.priority,
                    )
                except LookupError:
                    # optional=True: swallow the error and inject None.
                    # optional=False (default): re-raise so the caller sees the real error.
                    if is_optional:
                        return None
                    raise

            # ── NamedMeta / DelegateMeta / EventMeta (still inside Annotated) ──
            named_meta = next((a for a in args[1:] if isinstance(a, NamedMeta)), None)
            delegate_meta = next(
                (a for a in args[1:] if isinstance(a, DelegateMeta)), None
            )
            event_meta = next((a for a in args[1:] if isinstance(a, EventMeta)), None)

            if named_meta:
                try:
                    return self.get(effective_base_type, qualifier=named_meta.name)
                except LookupError:
                    return _UNRESOLVED
            elif delegate_meta:
                # Resolve the delegate: the inner bean that the @Decorator wraps.
                # Exclude the class currently being constructed to avoid self-injection.
                current_cls = _current_stack()[-1] if _current_stack() else None
                candidates = [
                    b
                    for b in self._filter(effective_base_type)
                    if not (
                        isinstance(b, ClassBinding) and b.implementation is current_cls
                    )
                ]
                if not candidates:
                    return _UNRESOLVED
                best = max(candidates, key=lambda b: b.priority or 0)
                return self._instantiate_sync(best)
            elif event_meta:
                return EventProxy(self, effective_base_type)

        # ── Union / Optional resolution ───────────────────────────
        # Handles: Optional[T], T | None, Union[T1, T2], Union[T1, T2, None]
        # Must come BEFORE the plain-type check below because Union types have
        # get_origin() != None (for typing.Union) or are types.UnionType instances,
        # neither of which is a registered binding — the plain-type branch would
        # call _is_resolvable(Union[T, None]) which always returns False.
        union_result = _unwrap_union(hint)
        if union_result is not None:
            candidates, is_optional = union_result
            # Try each non-None candidate in declaration order; return the first
            # that resolves. This mirrors how Python's runtime picks the first
            # match in isinstance() checks — predictable and declaration-order stable.
            for candidate in candidates:
                try:
                    return self.get(candidate)
                except LookupError:
                    # Binding not found for this candidate; try the next one.
                    continue
            # No candidate resolved. If NoneType was in the union, inject None
            # (same semantics as InjectMeta(optional=True)). Otherwise signal
            # _collect_kwargs that no binding was found — it will raise or fall
            # back to the parameter's default value.
            return None if is_optional else _UNRESOLVED

        elif (
            isinstance(hint, type) or get_origin(hint) is not None
        ) and self._is_resolvable(hint):
            # DESIGN: also accept generic aliases (e.g. Repository[User]) which are
            # not `type` instances but do have a get_origin().  Plain annotations
            # like `repo: Repository[User]` land here when no Inject[] wrapper is used.
            return self.get(hint)

        # ── InjectionPoint — plain type hint, not Annotated ────────────────────
        if hint is InjectionPoint:
            ip = _current_injection_point.get()
            return ip if ip is not None else _UNRESOLVED

        return _UNRESOLVED  # signal: no binding found, caller decides

    async def _resolve_hint_async(
        self, hint: Any, param_name: str, owner_name: str
    ) -> Any:
        """Resolve a single type hint to an instance, asynchronously.

        Async mirror of :meth:`_resolve_hint_sync`. Handles all four cases
        identically to the sync path, except inner resolution uses ``aget`` / ``aget_all``.
        LazyProxy creation is still synchronous — .aget() is called later by the owner.

        Args:
            hint:       The raw type hint (possibly ``Annotated``).
            param_name: Parameter name, used only for error messages.
            owner_name: Class or function name, used only for error messages.

        Returns:
            The resolved instance, or :data:`_UNRESOLVED` if no binding matches.
        """
        if get_origin(hint) is Annotated:
            args = get_args(hint)
            base_type = args[0]

            # ── Detect Optional[T] / T | None inside the wrapper (async mirror) ──
            # Identical logic to _resolve_hint_sync — see that method for the full
            # design rationale.  Duplicated here rather than extracted to a shared
            # helper so the sync and async paths remain independently readable.
            _base_union = _unwrap_union(base_type)
            if _base_union is not None and len(_base_union[0]) == 1 and _base_union[1]:
                effective_base_type: Any = _base_union[0][0]
                effective_optional: bool = True
            else:
                effective_base_type = base_type
                effective_optional = False

            # Mirror of _resolve_hint_sync — same priority order: Live → Lazy → Instance → Inject.
            live_meta = next((a for a in args[1:] if isinstance(a, LiveMeta)), None)
            lazy_meta = next((a for a in args[1:] if isinstance(a, LazyMeta)), None)
            instance_meta = next(
                (a for a in args[1:] if isinstance(a, InstanceMeta)), None
            )
            inject_meta = next((a for a in args[1:] if isinstance(a, InjectMeta)), None)

            if live_meta:
                # Proxy creation is always sync — the proxy's .aget() method is async.
                return LiveProxy(
                    self,
                    effective_base_type,
                    qualifier=live_meta.qualifier,
                    priority=live_meta.priority,
                    optional=effective_optional or live_meta.optional,
                )
            elif lazy_meta:
                # Proxy creation is always sync — the proxy's .aget() method is async.
                return LazyProxy(
                    self,
                    effective_base_type,
                    qualifier=lazy_meta.qualifier,
                    priority=lazy_meta.priority,
                    optional=effective_optional or lazy_meta.optional,
                )
            elif instance_meta:
                # Proxy creation is always sync — .aget() / .aget_all() are async.
                # No qualifier/priority baked in — caller supplies them at call time.
                return InstanceProxy(self, effective_base_type)
            elif inject_meta and inject_meta.all:
                inner = (
                    get_args(effective_base_type)[0]
                    if get_origin(effective_base_type) is list
                    else effective_base_type
                )
                return await self.aget_all(inner, qualifier=inject_meta.qualifier)
            elif inject_meta:
                is_optional = inject_meta.optional or effective_optional
                try:
                    return await self.aget(
                        effective_base_type,
                        qualifier=inject_meta.qualifier,
                        priority=inject_meta.priority,
                    )
                except LookupError:
                    if is_optional:
                        return None
                    raise

            # ── NamedMeta / DelegateMeta / EventMeta (async mirror) ────────────
            named_meta = next((a for a in args[1:] if isinstance(a, NamedMeta)), None)
            delegate_meta = next(
                (a for a in args[1:] if isinstance(a, DelegateMeta)), None
            )
            event_meta = next((a for a in args[1:] if isinstance(a, EventMeta)), None)

            if named_meta:
                try:
                    return await self.aget(
                        effective_base_type, qualifier=named_meta.name
                    )
                except LookupError:
                    return _UNRESOLVED
            elif delegate_meta:
                current_cls = _current_stack()[-1] if _current_stack() else None
                candidates = [
                    b
                    for b in self._filter(effective_base_type)
                    if not (
                        isinstance(b, ClassBinding) and b.implementation is current_cls
                    )
                ]
                if not candidates:
                    return _UNRESOLVED
                best = max(candidates, key=lambda b: b.priority or 0)
                return await self._instantiate_async(best)
            elif event_meta:
                return EventProxy(self, effective_base_type)

        # ── Union / Optional resolution (async mirror) ───────────────
        # Mirrors _resolve_hint_sync Union branch exactly — see that method
        # for the full design rationale.
        union_result = _unwrap_union(hint)
        if union_result is not None:
            candidates, is_optional = union_result
            for candidate in candidates:
                try:
                    return await self.aget(candidate)
                except LookupError:
                    continue
            return None if is_optional else _UNRESOLVED

        elif (
            isinstance(hint, type) or get_origin(hint) is not None
        ) and self._is_resolvable(hint):
            # Mirror of _resolve_hint_sync — accept generic aliases here too
            return await self.aget(hint)

        # ── InjectionPoint (async mirror) ───────────────────────────────────
        if hint is InjectionPoint:
            ip = _current_injection_point.get()
            return ip if ip is not None else _UNRESOLVED

        return _UNRESOLVED

    # ── Class-variable injection ───────────────────────────────────

    def _inject_class_vars_sync(self, instance: object, cls: type) -> None:
        """Resolve and set class-level annotated attributes on a freshly constructed instance.

        Class-level annotations like ``var: Inject[Something]`` are not part of
        ``__init__`` — they live in ``cls.__annotations__`` and are invisible to
        :meth:`_collect_kwargs_sync`. This method reads the full MRO-resolved hints
        for *cls* via :meth:`_resolve_class_annotations` (Phase 7 — evaluates each
        attribute's annotation in isolation rather than one whole-class
        ``get_type_hints(cls, include_extras=True)`` call), filters to those
        carrying providify metadata (``Inject[T]``, ``Live[T]``, ``Lazy[T]``), and
        sets each resolved value on the instance via ``setattr``.

        Called after ``cls(**kwargs)`` returns but before ``@PostConstruct`` fires,
        so injected class vars are visible to lifecycle hooks.

        Thread safety:  ✅ Safe — operates on a freshly constructed instance not yet
                        shared with other threads or tasks.
        Async safety:   ✅ Safe — no awaits, no shared state.

        Args:
            instance: The freshly constructed instance to inject into.
            cls:      The class whose type hints are inspected. Full MRO traversal
                      via :meth:`_resolve_class_annotations` — includes annotations
                      from parent classes.

        Returns:
            None

        Raises:
            LookupError: If a required class-var annotation (non-optional) refers to
                         a type that has no registered binding.
            AnnotationResolutionError: A class attribute's annotation IS (or
                plausibly is) an injection point but cannot be evaluated —
                see :meth:`_resolve_class_annotations`. Unresolvable
                annotations on attributes that are NOT injection points no
                longer affect construction at all (Phase 7).

        Edge cases:
            - cls has no annotations at all       → no-op (hints is empty)
            - annotation has no providify marker  → silently skipped
            - name also appears in __init__ sig   → skipped; constructor kwargs win
            - unresolvable name, not a marker      → silently skipped, no warning
            - unresolvable name, IS a marker       → raises, naming the attribute
        """
        hints = self._resolve_class_annotations(cls)

        if not hints:
            return

        # Constructor params already injected via _collect_kwargs_sync take priority.
        # Skip matching names to avoid overwriting values set by __init__.
        try:
            init_params = set(inspect.signature(cls.__init__).parameters.keys()) - {
                "self"
            }
        except (ValueError, TypeError):
            # __init__ may not be inspectable (e.g. C-extension types). Safe default.
            init_params = set()

        for name, hint in hints.items():
            if name in init_params:
                # Constructor already handled this — do not overwrite.
                continue
            if not _has_providify_metadata(hint):
                # Plain type annotation or bare ClassVar — not a DI injection target.
                continue
            # ClassVar[Instance[T]] expands to ClassVar[Annotated[T, InstanceMeta()]].
            # _resolve_hint_sync expects the Annotated form as its top-level type,
            # so strip the ClassVar wrapper before resolving.
            resolved = self._resolve_hint_sync(
                _unwrap_classvar(hint), name, cls.__name__
            )
            if resolved is not _UNRESOLVED:
                setattr(instance, name, resolved)

    async def _inject_class_vars_async(self, instance: object, cls: type) -> None:
        """Async mirror of :meth:`_inject_class_vars_sync`.

        Resolves class-level providify-annotated attributes asynchronously.
        ``Live[T]`` and ``Lazy[T]`` proxy objects are still created synchronously
        here — their ``.aget()`` methods are called later by the caller.

        Args:
            instance: The freshly constructed instance to inject into.
            cls:      The class whose type hints are inspected.

        Returns:
            None

        Raises:
            LookupError: If a required class-var annotation refers to an unregistered type.
            AnnotationResolutionError: See :meth:`_inject_class_vars_sync`.

        Edge cases: same as :meth:`_inject_class_vars_sync`.
        """
        hints = self._resolve_class_annotations(cls)

        if not hints:
            return

        try:
            init_params = set(inspect.signature(cls.__init__).parameters.keys()) - {
                "self"
            }
        except (ValueError, TypeError):
            init_params = set()

        for name, hint in hints.items():
            if name in init_params:
                continue
            if not _has_providify_metadata(hint):
                continue
            # Mirror of _inject_class_vars_sync — strip ClassVar[...] wrapper so
            # _resolve_hint_async receives a plain Annotated[T, Meta(...)] type.
            resolved = await self._resolve_hint_async(
                _unwrap_classvar(hint), name, cls.__name__
            )
            if resolved is not _UNRESOLVED:
                setattr(instance, name, resolved)

    # ── Constructor & provider resolution ─────────────────────────

    def _resolve_constructor(self, cls: type) -> object:
        """Resolve ``cls.__init__`` parameters and return a new instance.

        Pushes *cls* onto the per-task resolution stack before resolving its
        dependencies so that a circular reference is detected immediately.

        Args:
            cls: The class to instantiate.

        Returns:
            A newly constructed instance of *cls* with all dependencies injected.

        Raises:
            CircularDependencyError: If *cls* is already present in the
                current resolution stack.
            LookupError: If any required ``__init__`` parameter cannot be resolved.
        """
        self._check_cycle(cls)  # ✅ check before resolving

        # Push cls onto the stack for the duration of this resolution.
        # copy() — ContextVar is isolated per task, we build a new list.
        stack = _current_stack().copy()
        token = _resolution_stack.set(stack + [cls])

        try:
            resolved_kwargs = self._collect_kwargs_sync(cls.__init__, cls.__name__)
            instance = cls(**resolved_kwargs)
            # Inject class-level annotations (var: Inject[T], var: Live[T], etc.)
            # after construction — these are invisible to _collect_kwargs_sync which
            # only reads __init__ parameters.
            self._inject_class_vars_sync(instance, cls)
            return instance
        finally:
            _resolution_stack.reset(token)

    async def _resolve_constructor_async(self, cls: type) -> object:
        """Async mirror of :meth:`_resolve_constructor`.

        Args:
            cls: The class to instantiate.

        Returns:
            A newly constructed instance of *cls* with all dependencies injected.

        Raises:
            CircularDependencyError: If *cls* is already in the resolution stack.
            LookupError: If any required ``__init__`` parameter cannot be resolved.
        """
        self._check_cycle(cls)

        stack = _current_stack().copy()
        token = _resolution_stack.set(stack + [cls])

        try:
            resolved_kwargs = await self._collect_kwargs_async(
                cls.__init__, cls.__name__
            )
            instance = cls(**resolved_kwargs)
            # Async mirror — same class-var injection after construction.
            await self._inject_class_vars_async(instance, cls)
            return instance
        finally:
            _resolution_stack.reset(token)

    def _call_provider(self, fn: Callable[..., Any]) -> Any:
        """Call a sync provider function with all dependencies injected.

        If the provider declares a return type, that type is used as the cycle-
        detection key (same semantics as :meth:`_resolve_constructor`).

        Args:
            fn: The provider callable to invoke.

        Returns:
            The value returned by *fn*.

        Raises:
            CircularDependencyError: If the provider's return type is already
                present in the current resolution stack.
            LookupError: If any required parameter of *fn* cannot be resolved.
        """
        return_type = self._get_provider_return_type(fn)

        if return_type is not None:
            self._check_cycle(return_type)
            stack = _current_stack().copy()
            token = _resolution_stack.set(stack + [return_type])
        else:
            token = None

        try:
            resolved_kwargs = self._collect_kwargs_sync(fn, fn.__name__)
            return fn(**resolved_kwargs)
        finally:
            if token is not None:
                _resolution_stack.reset(token)

    async def _call_provider_async(self, fn: Callable[..., Any]) -> Any:
        """Call a provider function (sync or async) with all dependencies injected.

        Async mirror of :meth:`_call_provider`. The result is awaited if *fn*
        is a coroutine function, otherwise returned directly.

        Args:
            fn: The provider callable to invoke.

        Returns:
            The resolved value — awaited if *fn* is ``async def``.

        Raises:
            CircularDependencyError: If the provider's return type is already
                present in the current resolution stack.
            LookupError: If any required parameter of *fn* cannot be resolved.
        """
        return_type = self._get_provider_return_type(fn)

        if return_type is not None:
            self._check_cycle(return_type)
            stack = _current_stack().copy()
            token = _resolution_stack.set(stack + [return_type])
        else:
            token = None

        try:
            resolved_kwargs = await self._collect_kwargs_async(fn, fn.__name__)
            result = fn(**resolved_kwargs)
            return await result if inspect.iscoroutinefunction(fn) else result
        finally:
            if token is not None:
                _resolution_stack.reset(token)

    # ── Cycle detection ───────────────────────────────────────────

    def _check_cycle(self, cls: type) -> None:
        """Raise if *cls* is already present in the current resolution stack.

        Called before every constructor or provider resolution. If *cls* is
        already on the stack, we are about to enter an infinite loop.

        Args:
            cls: The type about to be resolved.

        Returns:
            None

        Raises:
            CircularDependencyError: When *cls* is already in the stack.
                The error message contains a formatted chain like ``A → B → A``.

        Example:
            stack = [A, B], cls = A  →  raises with "A → B → A"
        """
        stack = _current_stack()
        if cls in stack:
            raise CircularDependencyError(_format_cycle(stack, cls))

    def _get_provider_return_type(self, fn: Callable[..., Any]) -> type | None:
        """Read the ``return`` type hint from a provider function.

        Returns ``None`` (and logs a warning) if the hint cannot be resolved
        — e.g. when a forward reference is unresolvable at runtime. Tier 3 —
        advisory/reporting: a missing return type is a worse debugging
        experience, not a wiring bug, so the failure is swallowed but never
        silent.

        Phase 7: resolved via :func:`providify._annotations._eval_annotation`
        directly (not the whole-signature ``get_type_hints(fn)``) — an
        unresolvable PARAMETER annotation must never block resolving the
        return annotation, and vice versa; they are now fully independent
        (see :meth:`_collect_kwargs_sync` / :meth:`_resolve_params` for the
        parameter side, which no longer shares a single failure point with
        this method the way both did under the old whole-signature call).

        Args:
            fn: The provider callable to inspect.

        Returns:
            The return type annotation if present and resolvable, else ``None``.
        """
        sig = inspect.signature(inspect.unwrap(fn))
        raw_return = sig.return_annotation
        if raw_return is inspect.Signature.empty:
            return None
        globalns, localns = _annotation_namespaces(fn, self._build_localns())
        try:
            return _eval_annotation(raw_return, globalns, localns)
        except Exception as exc:
            logger.warning(
                "Cannot resolve return type hint for '%s' (%s: %s).",
                getattr(fn, "__qualname__", fn),
                type(exc).__name__,
                exc,
            )
            return None

    # ── Lifecycle hooks ───────────────────────────────────────────

    def _run_post_construct_sync(
        self,
        instance: Any,
        hook: LifecycleMarker | None,
    ) -> None:
        """Invoke the ``@PostConstruct`` lifecycle hook on *instance*, synchronously.

        A no-op when *hook* is ``None``.

        Args:
            instance: The freshly constructed object.
            hook:     The ``@PostConstruct`` marker, or ``None`` if absent.

        Returns:
            None

        Raises:
            RuntimeError: If the ``@PostConstruct`` method is ``async def`` —
                use :meth:`_run_post_construct_async` (via :meth:`aget`) instead.
        """
        if hook is None:
            return
        if hook.is_async:
            raise RuntimeError(
                f"@PostConstruct method '{hook.fn_name}' is async — "
                f"use await container.aget() to resolve this component."
            )
        getattr(instance, hook.fn_name)()

    async def _run_post_construct_async(
        self,
        instance: Any,
        hook: LifecycleMarker | None,
    ) -> None:
        """Invoke the ``@PostConstruct`` lifecycle hook on *instance*, asynchronously.

        Awaits the hook if it is ``async def``; calls it normally if sync.
        A no-op when *hook* is ``None``.

        Args:
            instance: The freshly constructed object.
            hook:     The ``@PostConstruct`` marker, or ``None`` if absent.

        Returns:
            None
        """
        if hook is None:
            return
        bound = getattr(instance, hook.fn_name)
        if hook.is_async:
            await bound()
        else:
            bound()

    # ── Scope context — convenience façade ───────────────────────
    #
    # DESIGN: these methods delegate to self.scope_context so callers
    # never need to access the attribute directly.  The container is
    # the single public entry point; scope_context is an implementation
    # detail.
    #
    #   Before:  with container.scope_context.request(): ...
    #   After:   with container.request(): ...

    def request(self) -> Any:
        """Activate a sync request scope context.

        Shorthand for ``container.scope_context.request()``.
        All @RequestScoped components resolved inside this block share one
        instance; a fresh instance is created for each new block.

        Returns:
            A sync context manager that yields the request ID string.

        Example:
            with container.request():
                svc = container.get(MyRequestScopedService)
        """
        return self.scope_context.request()

    def arequest(self) -> Any:
        """Activate an async request scope context.

        Shorthand for ``container.scope_context.arequest()``.

        Returns:
            An async context manager that yields the request ID string.

        Example:
            async with container.arequest():
                svc = await container.aget(MyRequestScopedService)
        """
        return self.scope_context.arequest()

    def session(self, session_id: str | None = None) -> Any:
        """Activate a sync session scope context.

        Shorthand for ``container.scope_context.session(session_id)``.
        Reuses an existing session cache when the same session_id is
        provided, creating a new one on first use.

        Args:
            session_id: Explicit session identifier (e.g. a user ID or
                        cookie value). A random UUID is used when omitted.

        Returns:
            A sync context manager that yields the session ID string.

        Example:
            with container.session("user-abc"):
                profile = container.get(UserProfile)
        """
        return self.scope_context.session(session_id)

    def asession(self, session_id: str | None = None) -> Any:
        """Activate an async session scope context.

        Shorthand for ``container.scope_context.asession(session_id)``.

        Args:
            session_id: Explicit session identifier. A random UUID is
                        used when omitted.

        Returns:
            An async context manager that yields the session ID string.

        Example:
            async with container.asession("user-abc"):
                async with container.arequest():
                    profile = await container.aget(UserProfile)
        """
        return self.scope_context.asession(session_id)

    def invalidate_session(self, session_id: str) -> None:
        """Destroy a session cache and run sync @PreDestroy hooks — call on logout or expiry.

        Runs @PreDestroy for all session-scoped instances in the cache before
        discarding it.  Async @PreDestroy hooks are skipped with a warning;
        use :meth:`ainvalidate_session` from an async context to handle them.

        Shorthand for ``container.scope_context.invalidate_session(session_id)``.

        Args:
            session_id: The session ID to invalidate.  No-op if unknown.

        Returns:
            None

        Edge cases:
            - Unknown session_id → no-op, no error raised.
            - Async @PreDestroy hooks on session-scoped instances are skipped;
              call ainvalidate_session() from an async context instead.
        """
        self.scope_context.invalidate_session(session_id)

    async def ainvalidate_session(self, session_id: str) -> None:
        """Destroy a session cache and run both sync and async @PreDestroy hooks.

        Async mirror of :meth:`invalidate_session` — awaits async @PreDestroy
        hooks in addition to calling sync ones, before discarding the cache.

        Args:
            session_id: The session ID to invalidate.  No-op if unknown.

        Returns:
            None

        Edge cases:
            - Unknown session_id → no-op, no error raised.

        Async safety:  ✅ Safe — delegates to ScopeContext.ainvalidate_session()
                       which protects dict mutations with a threading.Lock (not
                       held across await points).
        """
        await self.scope_context.ainvalidate_session(session_id)

    def set_scoped(self, tp: type, instance: object) -> None:
        """Register a pre-built instance into the currently active scope cache.

        This lets middleware (or any code that runs inside a ``request()`` /
        ``session()`` block) push an already-constructed value into the DI
        container so that later ``get(tp)`` calls return it directly — without
        invoking any provider or constructor.

        The request cache is preferred when both are active (request scope is
        more specific than session scope).

        Args:
            tp:       The type to register the instance under — must match
                      the type used in ``container.get(tp)`` at resolution time.
            instance: The pre-built instance to store.

        Returns:
            None

        Raises:
            RuntimeError: If neither a request nor a session scope context
                is currently active.

        Edge cases:
            - Calling set_scoped() twice with the same type overwrites the
              first value — last write wins within a scope.
            - The instance is only visible for the lifetime of the current
              scope block; it is discarded when the context manager exits.
            - set_scoped() uses the class itself as the cache key, matching
              the key produced by ClassBinding._get_cache_key().  Registering
              under a base class / interface requires a separate call.

        Example — FastAPI JWT middleware::

            @app.middleware("http")
            async def jwt_middleware(request: Request, call_next):
                raw = request.headers.get("Authorization", "")
                if raw.startswith("Bearer "):
                    token = decode_jwt(raw.removeprefix("Bearer "))
                    container.set_scoped(JWTToken, token)
                return await call_next(request)

        Thread safety:  ✅ Safe — writes to the per-request dict which is
                        isolated to the current ContextVar scope.
        Async safety:   ✅ Safe — each asyncio Task has its own request cache
                        via ContextVar; concurrent requests never interfere.
        """
        # Prefer the request cache — it is more specific and shorter-lived.
        # Fall back to session cache so set_scoped() also works inside
        # session-only blocks (e.g. session setup middleware without an
        # inner request block).
        cache = self.scope_context.get_request_cache()
        if cache is None:
            cache = self.scope_context.get_session_cache()
        if cache is None:
            raise RuntimeError(
                f"set_scoped({tp.__name__!r}) called outside any active scope context. "
                f"Wrap the call inside `with container.request():` or "
                f"`with container.session(...):` first."
            )
        # Cache key matches _get_cache_key() for ClassBinding — the concrete class.
        cache[tp] = instance

    # ── Shutdown ──────────────────────────────────────────────────

    def shutdown(self) -> None:
        """Sync shutdown — call ``@PreDestroy`` on all cached singleton instances.

        Raises if any ``@PreDestroy`` method is ``async def`` — use
        ``ashutdown()`` in that case. Clears all caches after teardown.

        Raises:
            RuntimeError: If any @PreDestroy hook is async def.
        """
        for binding in self._bindings:
            if isinstance(binding, ProviderBinding):
                if binding.disposer is not None and binding.scope == Scope.SINGLETON:
                    key = self._get_cache_key(binding)
                    instance = self._singleton_cache.get(key)
                    if instance is not None:
                        binding.disposer(instance)
                continue
            if not isinstance(binding, ClassBinding):
                continue
            if binding.pre_destroy is None:
                continue

            key = binding.implementation
            instance = self._singleton_cache.get(key)
            if instance is None:
                continue

            if binding.pre_destroy.is_async:
                raise RuntimeError(
                    f"@PreDestroy method '{binding.pre_destroy.fn_name}' on "
                    f"'{binding.implementation.__name__}' is async — "
                    f"use await container.ashutdown() instead."
                )
            getattr(instance, binding.pre_destroy.fn_name)()

        self._clear_caches()

    async def ashutdown(self) -> None:
        """Async shutdown — call ``@PreDestroy`` on all cached singleton instances.

        Awaits async ``@PreDestroy`` methods, calls sync ones normally.
        Clears all caches after teardown.

        Example:
            await container.ashutdown()
        """
        for binding in self._bindings:
            if isinstance(binding, ProviderBinding):
                if binding.disposer is not None and binding.scope == Scope.SINGLETON:
                    key = self._get_cache_key(binding)
                    instance = self._singleton_cache.get(key)
                    if instance is not None:
                        if inspect.iscoroutinefunction(binding.disposer):
                            await binding.disposer(instance)
                        else:
                            binding.disposer(instance)
                continue
            if not isinstance(binding, ClassBinding):
                continue
            if binding.pre_destroy is None:
                continue

            key = binding.implementation
            instance = self._singleton_cache.get(key)
            if instance is None:
                continue

            bound = getattr(instance, binding.pre_destroy.fn_name)
            if binding.pre_destroy.is_async:
                await bound()
            else:
                bound()

        self._clear_caches()

    def _clear_caches(self) -> None:
        """Clear all instance caches — called at the end of shutdown."""
        self._singleton_cache.clear()
        self.scope_context.clear_caches()

    # ── Scoped @PreDestroy callbacks ──────────────────────────────

    def _run_pre_destroy_for_scope(self, cache: dict[Any, object]) -> None:
        """Run sync @PreDestroy hooks for all cached instances in *cache*.

        Called by :class:`~providify.scope.ScopeContext` just before a
        request or session scope cache is popped.  Iterates ``_bindings``,
        finds each :class:`~providify.binding.ClassBinding` whose
        implementation class is a key in *cache*, and calls its
        ``pre_destroy`` hook if present.

        Async ``@PreDestroy`` hooks are skipped with a ``warnings.warn`` rather
        than raising — the sync context manager cannot await them.  Use the
        async context managers (``arequest()`` / ``asession()``) when async
        teardown is needed.

        Args:
            cache: The scope cache dict that is about to be discarded.
                   Keys are implementation classes (same as
                   :meth:`_get_cache_key` produces for ClassBinding).

        Returns:
            None

        Edge cases:
            - Empty cache                    → no-op.
            - Instance has no @PreDestroy    → silently skipped.
            - Async @PreDestroy encountered  → warning emitted, hook skipped.
            - Exception from a hook          → propagates after the cache is
                                               discarded (handled by finally).

        Thread safety:  ✅ Reads ``_bindings`` (no mutations during teardown).
        Async safety:   ✅ No await points — safe to call from sync context.

        Example:
            # Called automatically by ScopeContext — do not call directly.
        """
        for binding in self._bindings:
            if not isinstance(binding, ClassBinding):
                continue
            if binding.pre_destroy is None:
                continue
            key = binding.implementation
            instance = cache.get(key)
            if instance is None:
                continue
            if binding.pre_destroy.is_async:
                # DESIGN: sync path cannot await — warn and skip rather than
                # crash.  The async path (_arun_pre_destroy_for_scope) handles
                # async hooks correctly; use arequest()/asession() when needed.
                warnings.warn(
                    f"@PreDestroy method '{binding.pre_destroy.fn_name}' on "
                    f"'{binding.implementation.__name__}' is async — it will "
                    f"NOT be called in the sync request/session context. "
                    f"Use 'async with container.arequest():' or "
                    f"'async with container.asession():' instead.",
                    stacklevel=3,
                )
                continue
            getattr(instance, binding.pre_destroy.fn_name)()

    async def _arun_pre_destroy_for_scope(self, cache: dict[Any, object]) -> None:
        """Run all @PreDestroy hooks (sync + async) for *cache* instances.

        Async mirror of :meth:`_run_pre_destroy_for_scope`.  Called by
        :class:`~providify.scope.ScopeContext` before an async request or
        session scope cache is popped.  Unlike the sync version, this method
        awaits async ``@PreDestroy`` hooks and calls sync ones normally.

        Args:
            cache: The scope cache dict that is about to be discarded.

        Returns:
            None

        Edge cases:
            - Empty cache                    → no-op.
            - Instance has no @PreDestroy    → silently skipped.
            - Sync @PreDestroy               → called normally (no await).
            - Async @PreDestroy              → awaited ✅.
            - Exception from a hook          → propagates.

        Async safety:   ✅ Awaits async hooks; sync hooks called inline.
        Thread safety:  ✅ Reads ``_bindings`` only; no mutations during teardown.

        Example:
            # Called automatically by ScopeContext — do not call directly.
        """
        for binding in self._bindings:
            if not isinstance(binding, ClassBinding):
                continue
            if binding.pre_destroy is None:
                continue
            key = binding.implementation
            instance = cache.get(key)
            if instance is None:
                continue
            bound = getattr(instance, binding.pre_destroy.fn_name)
            if binding.pre_destroy.is_async:
                await bound()
            else:
                bound()

    # ── Scope-leak validation ─────────────────────────────────────

    def _collect_class_var_hints(self, cls: type) -> dict[str, Any]:
        """Return class-level type hints that carry providify metadata, excluding ``__init__`` params.

        Shared by :meth:`_check_scope_violation` and :meth:`_get_dependencies` so both
        scope-validation and dependency-graph construction see the same set of
        class-level injection points.

        Args:
            cls: The class whose annotations are inspected via full MRO traversal
                 (``get_type_hints`` walks parent classes too).

        Returns:
            ``dict[attr_name → hint]`` — only entries that carry providify metadata
            (``Inject[T]``, ``Live[T]``, ``Lazy[T]``) and are NOT ``__init__``
            parameters.

        Raises:
            AnnotationResolutionError: A class attribute IS (or plausibly is)
                an injection point but its annotation cannot be evaluated —
                see :meth:`_resolve_class_annotations`, which is strict by
                construction (Phase 7: an attribute that resolves to
                "unknown" ambiguity is skipped, never silently treated as
                "no injection points"). Callers on the reporting tier
                (:meth:`_get_dependencies`) catch this and downgrade it to a
                warning; validators let it propagate.

        Edge cases:
            - cls has no annotations              → ``{}``
            - an injection-point attribute's annotation is unresolvable
              → ``AnnotationResolutionError``
            - name is an ``__init__`` param       → excluded (already handled by
                                                    the ``__init__``-based callers)
            - name has no providify metadata      → excluded
        """
        # include_extras=True is implicit in _resolve_class_annotations —
        # without it Annotated[T, InjectMeta(...)] would be stripped to bare
        # T and the metadata marker lost.
        hints = self._resolve_class_annotations(cls)

        # Exclude __init__ params — they're already validated / graphed via the
        # existing __init__-based path.  Keeping them here would double-count them.
        try:
            init_params = set(inspect.signature(cls.__init__).parameters.keys()) - {
                "self"
            }
        except (ValueError, TypeError):
            # __init__ not inspectable (rare — C-extension types). Safe empty set.
            init_params = set()

        # _unwrap_classvar strips ClassVar[Annotated[T, Meta()]] → Annotated[T, Meta()].
        # All downstream callers (_check_scope_violation, _get_dependencies) inspect
        # hints with `get_origin(hint) is Annotated` — they'd silently skip ClassVar
        # wrappers without this normalisation step.
        return {
            name: _unwrap_classvar(hint)
            for name, hint in hints.items()
            if name not in init_params and _has_providify_metadata(hint)
        }

    def _check_scope_violation(
        self,
        binding: ClassBinding,
        qualifier: str | type | None = None,
        priority: int | None = None,
    ) -> list[ScopeLeak]:
        """Inspect *binding*'s ``__init__`` parameters for scope leaks.

        A scope leak occurs when a wider-scoped component (e.g. ``SINGLETON``)
        holds a direct reference to a narrower-scoped one (e.g. ``REQUEST``),
        because the wider component would silently cache a stale instance of
        the narrower one across scope boundaries.

        Scope ranking (lower = wider / longer-lived):
            ``SINGLETON(1) < SESSION(2) < REQUEST(3) < DEPENDENT(4)``

        Args:
            binding:   The ClassBinding whose constructor dependencies are inspected.
            qualifier: If given, only dependency bindings with this qualifier
                       are considered during the check.
            priority:  If given, only dependency bindings with this exact
                       priority are considered during the check.

        Returns:
            A list of :class:`~providify.metadata.ScopeLeak` instances, one
            per violating dependency. An empty list means no leaks were found.

        Raises:
            LiveInjectionRequiredError: If any ``REQUEST``/``SESSION`` scoped
                dependency is injected without ``Live[T]``/``Instance[T]``.
            AnnotationResolutionError: An ``__init__`` parameter (or class
                var) IS (or plausibly is) an injection point but its
                annotation cannot be evaluated — see :meth:`_resolve_params`
                / :meth:`_collect_class_var_hints`. A validator that cannot
                read the annotations must not report "no leaks found"; it
                raises instead so the container never reports a clean bill
                of health it cannot prove. Phase 7 narrows this further: an
                unresolvable annotation on a parameter that is NOT an
                injection point no longer raises at all — nothing to
                validate for it.
        """
        leaks: list[ScopeLeak] = []
        # Accumulated Live[T] violations — raised as a group so the developer
        # sees all affected parameters at once, not just the first one.
        live_violations: list[LiveInjectionViolation] = []
        # Per-parameter resolution (Phase 7) preserves Annotated wrappers
        # automatically (include_extras=True is baked into _eval_annotation)
        # and applies the container's localns per parameter — the whole-
        # signature `localns` gap this method used to patch manually
        # (`_resolve_hints_or_raise`) no longer exists as a distinct fix;
        # every parameter gets it via `_resolve_params` -> `_build_localns()`.
        init_hints = self._resolve_params(
            binding.implementation.__init__,
            f"{binding.implementation.__name__}.__init__",
            owner=binding.implementation,
        )

        # DESIGN: merge __init__ hints with class-level annotation hints so the
        # scope-leak check covers ALL injection points on the class, not just
        # constructor parameters.  _collect_class_var_hints already excludes
        # names present in __init__, so the merge is collision-free.
        hints = {**init_hints, **self._collect_class_var_hints(binding.implementation)}

        for param_name, hint in hints.items():
            # Extract the injection marker BEFORE stripping Annotated — we need
            # to know whether the caller used Inject[T], Lazy[T], Live[T], or a
            # bare type.  Bare type and Inject[T] are wrong for scoped deps;
            # Lazy[T] is also wrong (it caches after the first call); Live[T] is correct.
            inject_marker: _providify | None = None
            if get_origin(hint) is Annotated:
                args = get_args(hint)
                base_type = args[0]
                inject_marker = next(
                    (a for a in args[1:] if isinstance(a, _providify)), None
                )
            else:
                base_type = hint

            if not isinstance(base_type, type):
                continue

            dep_bindings = self._filter(
                base_type, qualifier=qualifier, priority=priority
            )
            for dep in dep_bindings:
                if not _is_scope_leak(parent_scope=binding.scope, dep_scope=dep.scope):
                    continue

                if dep.scope in (Scope.REQUEST, Scope.SESSION):
                    # REQUEST and SESSION scoped deps must always be wrapped in Live[T]
                    # or Instance[T] when held by a longer-lived component.
                    # Inject[T] and Lazy[T] both capture one instance at construction
                    # time — that instance becomes stale the moment the scope boundary
                    # rotates.  Instance[T] re-resolves on every .get() call (like
                    # Live[T]) so it is also safe here.
                    if not isinstance(inject_marker, LiveMeta | InstanceMeta):
                        live_violations.append(
                            LiveInjectionViolation(
                                binding=(binding.implementation, binding.scope),
                                dep=(base_type, dep.scope),
                                param_name=param_name,
                            )
                        )
                else:
                    # Non-scoped leak (e.g. SINGLETON holding a DEPENDENT dep).
                    # Instance[T] is exempt: the proxy defers resolution to .get()
                    # call time — the SINGLETON stores the proxy, never a resolved
                    # instance, so no stale reference is captured across scope boundaries.
                    if not isinstance(inject_marker, InstanceMeta):
                        leaks.append(
                            ScopeLeak(
                                binding=(binding.implementation, binding.scope),
                                reference=(dep.interface, dep.scope),
                            )
                        )

        if live_violations:
            raise LiveInjectionRequiredError(violations=live_violations)

        return leaks

    def _check_provider_scope_violation(
        self,
        binding: ProviderBinding,
    ) -> list[ScopeLeak]:
        """Inspect a provider function's parameters for scope leaks.

        Mirrors :meth:`_check_scope_violation` for :class:`ProviderBinding`.
        A ``@Provider(singleton=True)`` whose parameters include a
        ``REQUEST`` or ``SESSION`` scoped dependency without ``Live[T]``
        wrapping will silently capture a stale instance — the same risk
        that ``ClassBinding.validate()`` guards against in ``__init__``.

        Args:
            binding: The :class:`ProviderBinding` whose function parameters
                     are inspected for scope-narrowing dependency references.

        Returns:
            A list of :class:`~providify.metadata.ScopeLeak` instances, one
            per violating dependency.  Empty list means no leaks.

        Raises:
            LiveInjectionRequiredError: If any ``REQUEST`` or ``SESSION``
                scoped dependency is injected without ``Live[T]`` wrapping.
            AnnotationResolutionError: A parameter of *binding.fn* IS (or
                plausibly is) an injection point but its annotation cannot be
                resolved — see :meth:`_resolve_params`. A validator that
                cannot read the annotations must not report "no leaks
                found". Phase 7 narrows this further: an unresolvable
                annotation on a non-injected parameter no longer raises.

        Edge cases:
            - Provider with no parameters            → empty list, no error
            - Provider scope is DEPENDENT            → no leak risk, returns []
            - A parameter that IS an injection point but is unresolvable
              → ``AnnotationResolutionError``
            - Provider parameter is ``Live[T]``      → safe, not flagged
        """
        # DEPENDENT providers create a fresh instance every call — they never
        # hold a reference long enough to go stale.  Only SINGLETON and SESSION
        # can capture a narrower-scoped dep for longer than its lifetime.
        if binding.scope not in (Scope.SINGLETON, Scope.SESSION):
            return []

        leaks: list[ScopeLeak] = []
        live_violations: list[LiveInjectionViolation] = []

        # Per-parameter resolution (Phase 7) preserves Annotated wrappers
        # (include_extras=True baked into _eval_annotation) and applies the
        # container's localns per parameter automatically via _resolve_params.
        fn_hints = self._resolve_params(binding.fn, f"@Provider({binding.fn.__name__})")

        for param_name, hint in fn_hints.items():
            # Extract the injection marker BEFORE stripping Annotated — we need
            # to know whether the caller used Live[T] (safe) or bare type / Inject[T].
            inject_marker: _providify | None = None
            if get_origin(hint) is Annotated:
                args = get_args(hint)
                base_type = args[0]
                inject_marker = next(
                    (a for a in args[1:] if isinstance(a, _providify)), None
                )
            else:
                base_type = hint

            if not isinstance(base_type, type):
                continue

            dep_bindings = self._filter(base_type)
            for dep in dep_bindings:
                if not _is_scope_leak(parent_scope=binding.scope, dep_scope=dep.scope):
                    continue

                if dep.scope in (Scope.REQUEST, Scope.SESSION):
                    # REQUEST and SESSION scoped deps must be wrapped in Live[T].
                    # A singleton provider that receives a REQUEST-scoped param
                    # will call container.get(T) once and hold that instance —
                    # it becomes stale on the next request boundary.
                    if not isinstance(inject_marker, LiveMeta | InstanceMeta):
                        live_violations.append(
                            LiveInjectionViolation(
                                # ProviderBinding has no implementation class —
                                # use the provider function's name as an identifier.
                                binding=(
                                    type(f"@Provider({binding.fn.__name__})", (), {}),
                                    binding.scope,
                                ),
                                dep=(base_type, dep.scope),
                                param_name=param_name,
                            )
                        )
                else:
                    # Non-scoped leak (SINGLETON holding a narrower-scoped dep).
                    if not isinstance(inject_marker, InstanceMeta):
                        leaks.append(
                            ScopeLeak(
                                binding=(
                                    type(f"@Provider({binding.fn.__name__})", (), {}),
                                    binding.scope,
                                ),
                                reference=(dep.interface, dep.scope),
                            )
                        )

        if live_violations:
            raise LiveInjectionRequiredError(violations=live_violations)

        return leaks

    def validate_bindings(self) -> None:
        """Validate all registered bindings against the full registry.

        Iterates over every binding and calls
        :meth:`~providify.binding.Binding.validate`, which for
        :class:`~providify.binding.ClassBinding` instances performs
        scope-leak detection. This is the *phase transition* from registration
        to resolution: it runs once after all bindings have been registered,
        ensuring the complete dependency graph is visible during validation.

        Called automatically on the first :meth:`get`, :meth:`aget`,
        :meth:`get_all`, or :meth:`aget_all` call if not already validated.
        Can also be called explicitly for early error detection.

        Returns:
            None

        Raises:
            ScopeViolationDetectedError: If any binding introduces a scope leak.
        """
        for binding in self._bindings:
            binding.validate(self)

    def validate_all(self) -> list[str]:
        """Validate all bindings and return a list of violation messages.

        Unlike :meth:`validate_bindings`, this method does NOT raise — it
        collects every violation across all bindings in a single pass and
        returns them as human-readable strings.  An empty list means the
        container is fully valid.

        This is the recommended pre-startup validation call: it surfaces ALL
        scope misconfigurations in one shot rather than stopping at the first
        one, making it easier to fix the whole graph in one go.

        Sets ``_validated = True`` only when the returned list is empty,
        so the next ``get()`` call skips re-validation for valid containers.

        Returns:
            A list of violation message strings (one per failing binding).
            Empty list → all bindings are valid.

        Thread safety:  ⚠️ Not safe for concurrent mutation — call before the
                        app goes multi-threaded.
        Async safety:   ✅ No await points.

        Edge cases:
            - No bindings registered → returns [] immediately.
            - Partial validity → returns messages only for the failing bindings;
              valid bindings are silently accepted.
            - Calling validate_all() when _validated is already True still
              re-runs validation (idempotent but slightly redundant).

        Example:
            violations = container.validate_all()
            if violations:
                for msg in violations:
                    logger.error("DI violation: %s", msg)
                raise RuntimeError("Container has scope violations — aborting startup")
        """
        violations: list[str] = []
        for binding in self._bindings:
            try:
                binding.validate(self)
            except Exception as e:
                # Collect every violation message rather than stopping at the first.
                # The exception message contains the actionable fix suggestion.
                violations.append(str(e))
        # Only mark validated when everything is clean — a container with
        # violations must still re-validate after the caller fixes the bindings.
        if not violations:
            self._validated = True
        return violations

    @property
    def is_valid(self) -> bool:
        """Return True if :meth:`validate_bindings` has run successfully.

        Reflects whether ``_validated`` is True — i.e. at least one successful
        validation pass has completed since the last binding mutation.

        Note: this is a snapshot — it becomes False whenever a new binding is
        added (via ``bind()``, ``register()``, ``provide()``, ``override()``,
        or ``reset_binding()``), forcing re-validation on the next ``get()`` call.

        Returns:
            True  — container has been validated and no bindings were added since.
            False — container has never been validated, or a binding was added
                    after the last validation pass.

        Thread safety:  ✅ Reading a bool is atomic under the GIL.
        Async safety:   ✅ No shared mutable state accessed.

        Example:
            container.validate_all()
            assert container.is_valid is True
            container.bind(NewService, NewServiceImpl)
            assert container.is_valid is False  # mutation resets the flag
        """
        return self._validated

    # ── Dependency graph ──────────────────────────────────────────

    def _get_dependencies(
        self,
        binding: AnyBinding,
        _visited: frozenset[type] | None = None,
    ) -> list[AnyBinding]:
        """Dispatch to the correct dependency-collection strategy for a binding.

        Acts as a type-based router — delegates to ``_collect_dependencies``
        for both ``ClassBinding`` and ``ProviderBinding``. Raises immediately
        for unknown binding types so that missing implementations are caught at
        resolve-time rather than silently returning an empty list.

        Args:
            binding:  The binding whose constructor/provider signature will be
                      inspected to discover its dependencies.
            _visited: Optional frozenset of interface types already seen by the
                      caller during a recursive graph traversal. When provided,
                      any dep whose interface is already in ``_visited`` is
                      filtered out — preventing infinite loops for callers that
                      do NOT have their own cycle guard.

                      IMPORTANT: ``describe()`` does NOT pass ``_visited`` here
                      because it maintains its own cycle guard and needs the
                      cyclic dep binding to be returned so it can render the
                      ``[CYCLE DETECTED]`` sentinel.

        Returns:
            Ordered list of ``AnyBinding`` objects that *binding* depends on.

        Raises:
            TypeError: *binding* is not a ``ClassBinding`` or ``ProviderBinding``.

        Edge cases:
            - Class-var hints for a ``ClassBinding`` fail to resolve
              (``AnnotationResolutionError`` from :meth:`_collect_class_var_hints`)
              → downgraded to a logged warning; the class-var deps are omitted
              from the returned list but ``__init__`` deps are unaffected. This
              tier is reporting/enrichment (``describe()``), not wiring, so a
              partial graph beats aborting the whole traversal.
        """
        if isinstance(binding, ClassBinding):
            deps = self._collect_dependencies(
                fn=binding.implementation.__init__,
                qualifier=binding.qualifier,
                priority=binding.priority,
            )
            # Extend with class-level annotated attributes — these are injection
            # points too (var: Inject[T]), but invisible to _collect_dependencies
            # which only reads __init__.  The helper already filters to hints that
            # carry providify metadata and excludes __init__ param names.
            #
            # Tier downgrade: _collect_class_var_hints is strict (raises
            # AnnotationResolutionError) because its OTHER caller is a
            # validator. Here we are building a dependency graph for
            # describe() — advisory/reporting, not wiring — so a resolution
            # failure is downgraded to a logged warning and a partial graph,
            # rather than aborting the whole graph traversal.
            try:
                class_var_hints = self._collect_class_var_hints(binding.implementation)
            except AnnotationResolutionError as exc:
                logger.warning(
                    "Dependency graph for '%s' is incomplete: %s",
                    binding.implementation.__name__,
                    exc,
                )
                class_var_hints = {}
            for hint in class_var_hints.values():
                resolved = self._resolve_dependency(
                    hint,
                    qualifier=binding.qualifier,
                    priority=binding.priority,
                )
                if resolved is not None:
                    deps.append(resolved)
        elif isinstance(binding, ProviderBinding):
            deps = self._collect_dependencies(
                fn=binding.fn,
                qualifier=binding.qualifier,
                priority=binding.priority,
            )
        else:
            raise TypeError(
                f"No _get_dependencies implementation found for binding type "
                f"'{type(binding).__name__}'. Expected ClassBinding or ProviderBinding."
            )

        if _visited is None:
            return deps

        return [d for d in deps if d.interface not in _visited]

    # ── Scanning & module installation ────────────────────────────

    def scan(self, module: str | ModuleType, *, recursive: bool = False) -> None:
        """Scan a module for DI-decorated classes and functions.

        Delegates to the configured :class:`~providify.scanner.ContainerScanner`
        (defaults to :class:`~providify.scanner.DefaultContainerScanner`).

        Args:
            module:    A fully-qualified module name or an already-imported module.
            recursive: When ``True``, sub-packages are walked recursively.

        Returns:
            None

        Raises:
            ModuleNotFoundError: If *module* is a string that cannot be imported.
        """
        self._scanner.scan(module, recursive=recursive)

    def install(self, module_cls: type) -> None:
        """Install a ``@Configuration`` module synchronously.

        Instantiates *module_cls* with its constructor dependencies injected
        (Spring-style), then registers every ``@Provider``-decorated method on
        the module as a bound-method binding.

        Args:
            module_cls: A class decorated with ``@Configuration``.

        Returns:
            None

        Raises:
            TypeError:    If *module_cls* is not decorated with ``@Configuration``.
            LookupError:  If any constructor dependency of *module_cls* has no binding.
            RuntimeError: If any constructor dependency is async-only —
                          use :meth:`ainstall` instead.

        Example:
            container.bind(Settings, AppSettings)
            container.install(InfraModule)
        """
        if not _has_configuration_module(module_cls):
            raise TypeError(
                f"{module_cls.__name__} must be decorated with @Configuration."
            )
        instance = self._resolve_constructor(module_cls)
        self._register_module_providers(module_cls, instance)

    async def ainstall(self, module_cls: type) -> None:
        """Install a ``@Configuration`` module asynchronously.

        Async mirror of :meth:`install`. Use when the module's constructor
        has async-only dependencies (i.e. deps that require ``aget()``).

        Args:
            module_cls: A class decorated with ``@Configuration``.

        Returns:
            None

        Raises:
            TypeError:   If *module_cls* is not decorated with ``@Configuration``.
            LookupError: If any constructor dependency of *module_cls* has no binding.

        Example:
            await container.ainstall(InfraModule)
        """
        if not _has_configuration_module(module_cls):
            raise TypeError(
                f"{module_cls.__name__} must be decorated with @Configuration."
            )
        instance = await self._resolve_constructor_async(module_cls)
        self._register_module_providers(module_cls, instance)

    def _register_module_providers(self, module_cls: type, instance: object) -> None:
        """Register every ``@Provider``-decorated method from a module instance.

        Iterates over the class's own attributes (not inherited ones) to find
        ``@Provider``-decorated methods. ``vars()`` gives the raw unbound functions,
        which carry ``ProviderMetadata`` directly on their ``__dict__``.

        Also wires ``@Disposes`` methods to their corresponding ``ProviderBinding``.

        Args:
            module_cls: The ``@Configuration`` class to inspect.
            instance:   The live module instance — getattr returns bound methods.

        Returns:
            None
        """
        for name, fn in vars(module_cls).items():
            if name == "__init__":
                continue
            # Unwrap @property so that @Provider @property works naturally.
            effective_fn = fn.fget if isinstance(fn, property) else fn
            if (
                callable(effective_fn)
                and _get_provider_metadata(effective_fn) is not None
            ):
                if isinstance(fn, property):
                    # Wrap the property getter as a bound-method-like callable.
                    # functools.wraps copies __module__, __globals__, __annotations__,
                    # and __wrapped__ so that ProviderBinding can evaluate the
                    # return-type annotation in the correct namespace.
                    captured = fn
                    bound_instance = instance

                    @functools.wraps(effective_fn)
                    def _prop_provider(prop=captured, obj=bound_instance) -> Any:
                        return prop.fget(obj)

                    # Copy provider metadata (stamped in __dict__ by @Provider)
                    _prop_provider.__dict__.update(effective_fn.__dict__)
                    self.provide(_prop_provider)
                else:
                    # getattr returns a bound method — self is the live module instance.
                    self.provide(getattr(instance, name))

        # Wire @Disposes teardown methods to their ProviderBinding
        for name, fn in vars(module_cls).items():
            if not callable(fn):
                continue
            disposes_marker = _get_disposes_marker(fn)
            if disposes_marker is None:
                continue
            disposed_type = disposes_marker.disposed_type
            for binding in self._bindings:
                if isinstance(binding, ProviderBinding) and _interface_matches(
                    binding.interface, disposed_type
                ):
                    binding.disposer = getattr(instance, name)
                    break

    # ── Describe ──────────────────────────────────────────────────

    def describe(self) -> DIContainerDescriptor:
        """Build a full ``DIContainerDescriptor`` snapshot of this container.

        Recursively describes every registered binding and its dependency tree.
        The result is a plain, serialisable object — safe to render, log, or
        convert to JSON via :meth:`~providify.descriptor.DIContainerDescriptor.to_dict`.

        Returns:
            A :class:`~providify.descriptor.DIContainerDescriptor` containing
            all binding descriptors grouped by scope.

        Example:
            descriptor = container.describe()
            print(descriptor)           # renders grouped ASCII tree
            data = descriptor.to_dict() # JSON-serialisable dict
        """
        return DIContainerDescriptor(
            validated=self._validated,
            bindings=tuple(b.describe(self) for b in self._bindings),
        )

    # ── Introspection (Feature 10) ────────────────────────────────

    def get_binding(
        self,
        interface: type,
        *,
        qualifier: str | type | None = None,
        priority: int | None = None,
    ) -> AnyBinding:
        """Return the highest-priority binding for *interface* without instantiating it.

        A pure read — does NOT trigger ``validate_bindings()`` or create any
        instances. Useful for test introspection, migration scripts, and
        tooling that inspects the container registry.

        Args:
            interface:  The type to look up (concrete class or interface).
            qualifier:  If given, only bindings registered with this qualifier
                        are considered.
            priority:   If given, only bindings with this exact priority value
                        are considered.

        Returns:
            The highest-priority matching :class:`~providify.binding.AnyBinding`.

        Raises:
            LookupError: If no binding is registered for *interface* with
                         the given qualifier / priority.

        Edge cases:
            - Called before ``get()``       → does NOT trigger validate_bindings().
            - exact_only self-bindings      → included when *interface* is the
                                              concrete class itself.
            - No bindings at all            → raises LookupError.

        Thread safety:  ✅ Read-only; no shared state mutated.
        Async safety:   ✅ No await points.

        Example:
            binding = container.get_binding(UserRepository)
            print(binding.scope)  # Scope.SINGLETON
        """
        return self._get_best_candidate(
            interface, qualifier=qualifier, priority=priority
        )

    def get_all_bindings(
        self,
        interface: type,
        *,
        qualifier: str | type | None = None,
    ) -> list[AnyBinding]:
        """Return all registered bindings for *interface* without instantiating them.

        A pure read — does NOT trigger ``validate_bindings()`` or create any
        instances. Returns an empty list (never raises LookupError) when no
        bindings match.

        Args:
            interface: The type to look up.
            qualifier: If given, only bindings with this qualifier are returned.

        Returns:
            A list of all matching bindings, in registration order.
            Returns ``[]`` if none are registered.

        Edge cases:
            - No bindings match → returns [] (differs from get_all() which raises).
            - Called before get() → does NOT trigger validate_bindings().

        Thread safety:  ✅ Read-only; no shared state mutated.
        Async safety:   ✅ No await points.

        Example:
            bindings = container.get_all_bindings(NotificationService)
            for b in bindings:
                print(b.scope, b.qualifier)
        """
        return self._filter(interface, qualifier=qualifier)

    # ── Override (Feature 5) ──────────────────────────────────────

    def override(self, interface: Any, implementation: type) -> None:
        """Replace all bindings for *interface* with a new implementation.

        Removes every :class:`~providify.binding.ClassBinding` where
        ``binding.interface == interface``, evicts the previous implementations
        from the singleton cache, then calls :meth:`bind` to register the
        replacement.

        Resets validation state so scope-leak checks run again on the next
        ``get()`` / ``aget()`` call.

        Intended for test overrides — swapping a real service with a fake
        without rebuilding the container.

        Args:
            interface:      The interface type to override.
            implementation: The replacement concrete class.

        Returns:
            None

        Edge cases:
            - Interface not registered → no-op (no error raised).  The new
              binding is still registered via ``bind()``.
            - Only :class:`~providify.binding.ClassBinding` entries are removed.
              :class:`~providify.binding.ProviderBinding` entries for the same
              interface are left in place.
            - Singleton cache entries for the *previous* implementation are
              evicted so the new impl gets a fresh start.

        Thread safety:  ⚠️ Not safe for concurrent use — call before the app
                        goes multi-threaded.
        Async safety:   ✅ No await points.

        Example:
            container.bind(Notifier, RealNotifier)
            container.override(Notifier, FakeNotifier)  # test swap
            svc = container.get(Notifier)               # FakeNotifier
        """
        # Collect implementation classes for cache eviction before mutating
        # _bindings — otherwise we'd evict entries we've already removed.
        to_evict: list[Any] = [
            b.implementation
            for b in self._bindings
            if isinstance(b, ClassBinding) and b.interface is interface
        ]

        # Remove all ClassBinding entries that map *interface* → anything.
        # DESIGN: list comprehension (rebuild) rather than in-place removal so
        # iteration order is preserved and there is no index-shift bug.
        self._bindings = [
            b
            for b in self._bindings
            if not (isinstance(b, ClassBinding) and b.interface is interface)
        ]

        # Evict previous singletons — stale instances must not survive the swap.
        for key in to_evict:
            self._singleton_cache.pop(key, None)
            self._singleton_locks.pop(key, None)
            self._async_singleton_locks.pop(key, None)

        # Register the replacement via the public bind() API — which also
        # resets _validated and _localns_cache.
        self.bind(interface, implementation)

    # ── Reset binding (Feature 12) ────────────────────────────────

    def reset_binding(
        self,
        interface: Any,
        *,
        qualifier: str | type | None = None,
    ) -> int:
        """Remove all bindings for *interface* and evict cached instances.

        Mirrors :meth:`override` but without registering a replacement.
        After this call, :meth:`is_resolvable` returns ``False`` for
        *interface* with the given qualifier.

        Args:
            interface:  The interface type to remove.
            qualifier:  If given, only bindings with this exact qualifier are
                        removed.  ``None`` removes ALL bindings for *interface*
                        regardless of qualifier.

        Returns:
            The number of bindings removed (0 means not found — no error raised).

        Edge cases:
            - Interface not registered                → returns 0, no error.
            - Singleton cache evicted for removed keys → subsequent get() creates
                                                         a fresh instance (if
                                                         re-bound before then).
            - Both ClassBinding and ProviderBinding entries are removed.

        Thread safety:  ⚠️ Not safe for concurrent use.
        Async safety:   ✅ No await points.

        Example:
            container.register(MyService)
            container.get(MyService)          # caches singleton
            n = container.reset_binding(MyService)
            assert n == 1
            assert not container.is_resolvable(MyService)
        """
        to_remove = [
            b
            for b in self._bindings
            if _interface_matches(b.interface, interface)
            and (qualifier is None or b.qualifier == qualifier)
        ]

        if not to_remove:
            return 0

        # Collect cache keys before removal
        to_evict: list[Any] = []
        for b in to_remove:
            if isinstance(b, ClassBinding):
                to_evict.append(b.implementation)
            else:
                to_evict.append(b.fn)  # type: ignore[union-attr]

        # Rebuild _bindings without the removed entries
        remove_set = set(id(b) for b in to_remove)
        self._bindings = [b for b in self._bindings if id(b) not in remove_set]

        # Evict cached instances
        for key in to_evict:
            self._singleton_cache.pop(key, None)
            self._singleton_locks.pop(key, None)
            self._async_singleton_locks.pop(key, None)

        # Reset validation so scope checks run again
        self._validated = False
        self._invalidate_type_caches()

        return len(to_remove)

    # ── copy() ────────────────────────────────────────────────────

    def copy(self) -> DIContainer:
        """Return a new container with the same bindings but no shared cache state.

        Creates a structurally identical container suitable for test overrides —
        the caller can ``override()`` or ``reset_binding()`` on the copy without
        affecting the original.  All binding objects are shared (shallow copy)
        which is safe because ``AnyBinding`` attributes are immutable after
        ``__init__``.

        The copy starts unvalidated (``_validated = False``) so scope-leak
        checks run afresh on its first ``get()`` call.  Singleton caches,
        scope contexts, and lock dicts are NOT shared — each container manages
        its own instance lifecycle independently.

        Returns:
            A new ``DIContainer`` with a shallow copy of ``_bindings`` and
            fresh (empty) caches and locks.

        Thread safety:  ⚠️ Not safe to call concurrently with mutations on
                        the source container — ``list(self._bindings)`` iterates
                        the list under no lock.  Call ``copy()`` during startup
                        before the container goes multi-threaded.
        Async safety:   ✅ No await points.

        Edge cases:
            - Empty container → copy is also empty, no error.
            - Singletons already cached in the source container are NOT present
              in the copy — the copy must re-instantiate them on first get().
            - Scanner is not copied — the copy gets its own DefaultContainerScanner
              that points at itself.  Auto-scan (``scan=`` constructor arg) does
              NOT re-run on copy.

        Example:
            base = build_app_container()
            test_c = base.copy()
            test_c.override(Database, FakeDatabase)
            svc = test_c.get(UserService)  # gets FakeDatabase
            svc2 = base.get(UserService)   # still gets real Database ✅
        """
        # DESIGN: use __new__ to bypass __init__ entirely.
        # __init__ scans modules and sets up the full wiring; we only want
        # to clone the binding list.  __new__ gives us a blank instance that
        # we populate manually — the same pattern used by pickle.__reduce__.
        #
        # Tradeoffs:
        #   ✅ No module re-scan, no double-registration from the auto-scan path
        #   ✅ All caches start empty — predictable state for test isolation
        #   ❌ Fragile if __init__ adds new attributes in the future — this
        #      method must be kept in sync.  Mitigation: the test suite covers
        #      copy() behaviour, so attribute additions cause obvious test failures.
        new = DIContainer.__new__(DIContainer)
        # Shallow-copy the binding list — bindings are immutable value objects
        new._bindings = list(self._bindings)
        # Fresh caches — no state bleeds from source to copy
        new._singleton_cache = {}
        new._singleton_locks = {}
        new._singleton_lock_guard = threading.Lock()
        new._async_singleton_locks = {}
        # Fresh scope context wired to the new container's own PreDestroy callbacks
        new.scope_context = ScopeContext(
            on_scope_exit=new._run_pre_destroy_for_scope,
            on_scope_exit_async=new._arun_pre_destroy_for_scope,
            on_invalidate_session=new._run_pre_destroy_for_scope,
            on_invalidate_session_async=new._arun_pre_destroy_for_scope,
        )
        # Fresh scanner pointing at the new container
        new._scanner = DefaultContainerScanner(new)
        # Not validated — scope checks run on first get()
        new._validated = False
        # localns/hints caches reset — built from _bindings, must reflect the
        # copy's own list, and NEVER share the parent's dict object (a
        # binding mutation on one container must not silently poison the
        # other's cached hints). Set directly rather than via
        # `_invalidate_type_caches()` because `new` is constructed with
        # `__new__` — `_hints_cache` does not exist yet for that method to
        # clear.
        new._localns_cache = None
        new._hints_cache = {}
        # Copy runtime state introduced in v0.3.0
        new._enabled_alternatives = set(self._enabled_alternatives)
        new._interceptor_classes = list(self._interceptor_classes)
        new._observers = {}  # observers are re-registered as instances are created
        new._tracked_dependents = []
        return new

    # ── __repr__ (Feature 14) ─────────────────────────────────────

    def __repr__(self) -> str:
        """Return a human-readable summary with per-scope binding counts.

        Shows counts only for scopes that have at least one binding so the
        output stays compact.

        Returns:
            A string like:
            ``DIContainer(singleton=3, request=2, dependent=6, validated=True)``

        Example:
            repr(container)
            # → 'DIContainer(singleton=2, dependent=4, validated=False)'

        Thread safety:  ✅ Read-only; iterates _bindings under GIL.
        Async safety:   ✅ No await points.
        """
        # DESIGN: collections.Counter maps Scope → count in a single pass.
        # Only scopes with count > 0 are shown — keeps output minimal.
        counts: collections.Counter[str] = collections.Counter(
            b.scope.name.lower() for b in self._bindings
        )
        scope_parts = ", ".join(
            f"{name}={count}"
            for name, count in [
                ("singleton", counts.get("singleton", 0)),
                ("request", counts.get("request", 0)),
                ("session", counts.get("session", 0)),
                ("dependent", counts.get("dependent", 0)),
            ]
            if count > 0
        )
        if scope_parts:
            return f"DIContainer({scope_parts}, validated={self._validated})"
        return f"DIContainer(validated={self._validated})"
